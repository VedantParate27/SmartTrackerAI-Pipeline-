"""
Builds backend/smarttracker.db from schema.sql (+ seed.sql if present).
Safe to re-run: DB_PATH is deleted and rebuilt from scratch each time.

Run from inside backend/:
    python init_db.py
"""
import sqlite3
from pathlib import Path

HERE = Path(__file__).parent
DB_PATH = HERE / "smarttracker.db"
SCHEMA_PATH = HERE / "schema.sql"
SEED_PATH = HERE / "seed.sql"


def main():
    if DB_PATH.exists():
        DB_PATH.unlink()
        print(f"Removed existing {DB_PATH.name}")

    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")

    conn.executescript(SCHEMA_PATH.read_text(encoding="utf-8"))
    print("Schema applied.")

    if SEED_PATH.exists():
        conn.executescript(SEED_PATH.read_text(encoding="utf-8"))
        print("Seed data inserted.")

    # Self-check: foreign_keys pragma is per-connection, not persisted in
    # the file, so confirm it actually took effect on this connection.
    fk_status = conn.execute("PRAGMA foreign_keys").fetchone()[0]
    assert fk_status == 1, "Foreign key enforcement did not enable correctly"
    print("Foreign key enforcement confirmed ON.")

    tables = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
    ).fetchall()
    print(f"Tables created: {[t[0] for t in tables]}")

    conn.commit()
    conn.close()
    print(f"\n{DB_PATH.name} ready at {DB_PATH.resolve()}")


if __name__ == "__main__":
    main()
