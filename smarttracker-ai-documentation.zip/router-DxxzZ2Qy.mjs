import { r as __toESM } from "../_runtime.mjs";
import { c as SESSIONS, f as TAXONOMY_VERSION, m as canTransition, n as CLASSIFIER_VERSION, o as GENERATION_MODEL, r as CONFIG } from "./taxonomy-tJaYsAgr.mjs";
import { i as SEED_CASES, n as POLICY_CHUNKS, r as POLICY_DOCUMENTS } from "./seed-CgRMZeL5.mjs";
import { R as require_react, _ as Link, f as createRouter, g as createRootRoute, h as createFileRoute, l as Scripts, m as lazyRouteComponent, u as HeadContent, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-DxxzZ2Qy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "mt-auto border-t border-(--line) py-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "wrap flex flex-col gap-2 text-xs muted sm:flex-row sm:items-center sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "m-0",
				children: "SmartTracker AI — intelligent grievance routing and resolution pipeline. AI assists triage; it does not replace human judgement."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "m-0 subtle",
				children: "SRS v1.0 · academic project prototype"
			})]
		})
	});
}
function getInitialMode() {
	if (typeof window === "undefined") return "auto";
	const stored = window.localStorage.getItem("theme");
	if (stored === "light" || stored === "dark" || stored === "auto") return stored;
	return "auto";
}
function applyThemeMode(mode) {
	const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
	const resolved = mode === "auto" ? prefersDark ? "dark" : "light" : mode;
	document.documentElement.classList.remove("light", "dark");
	document.documentElement.classList.add(resolved);
	if (mode === "auto") document.documentElement.removeAttribute("data-theme");
	else document.documentElement.setAttribute("data-theme", mode);
	document.documentElement.style.colorScheme = resolved;
}
function ThemeToggle() {
	const [mode, setMode] = (0, import_react.useState)("auto");
	(0, import_react.useEffect)(() => {
		const initialMode = getInitialMode();
		setMode(initialMode);
		applyThemeMode(initialMode);
	}, []);
	(0, import_react.useEffect)(() => {
		if (mode !== "auto") return;
		const media = window.matchMedia("(prefers-color-scheme: dark)");
		const onChange = () => applyThemeMode("auto");
		media.addEventListener("change", onChange);
		return () => {
			media.removeEventListener("change", onChange);
		};
	}, [mode]);
	function toggleMode() {
		const nextMode = mode === "light" ? "dark" : mode === "dark" ? "auto" : "light";
		setMode(nextMode);
		applyThemeMode(nextMode);
		window.localStorage.setItem("theme", nextMode);
	}
	const label = mode === "auto" ? "Theme mode: auto (system). Click to switch to light mode." : `Theme mode: ${mode}. Click to switch mode.`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: toggleMode,
		"aria-label": label,
		title: label,
		className: "btn btn-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			"aria-hidden": "true",
			children: mode === "auto" ? "◐" : mode === "dark" ? "☾" : "☀"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "hidden sm:inline",
			children: mode === "auto" ? "Auto" : mode === "dark" ? "Dark" : "Light"
		})]
	});
}
var LINKS = [
	{
		to: "/",
		label: "Home"
	},
	{
		to: "/submit",
		label: "Submit grievance"
	},
	{
		to: "/track",
		label: "Track status"
	},
	{
		to: "/guide",
		label: "Document guide"
	},
	{
		to: "/admin",
		label: "Admin"
	},
	{
		to: "/cleaner",
		label: "Cleaner"
	},
	{
		to: "/login",
		label: "Sign in"
	}
];
function Header() {
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "site-header",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "wrap flex items-center gap-3 py-2.5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "brand",
					onClick: () => setOpen(false),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "brand-mark",
						"aria-hidden": "true",
						children: "ST"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["SmartTracker", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-(--accent)",
						children: " AI"
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					"aria-label": "Main",
					className: "ml-auto hidden items-center gap-0.5 md:flex",
					children: LINKS.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: link.to,
						className: "nav-link",
						activeProps: { className: "nav-link is-active" },
						activeOptions: { exact: link.to === "/" },
						children: link.label
					}, link.to))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ml-auto flex items-center gap-1.5 md:ml-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeToggle, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "btn btn-sm md:hidden",
						"aria-expanded": open,
						"aria-controls": "mobile-nav",
						onClick: () => setOpen((value) => !value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": "true",
							children: open ? "✕" : "☰"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sr-only",
							children: open ? "Close navigation menu" : "Open navigation menu"
						})]
					})]
				})
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			id: "mobile-nav",
			"aria-label": "Main",
			className: "wrap border-t border-(--line) pb-3 pt-2 md:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "m-0 grid list-none gap-0.5 p-0",
				children: LINKS.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: link.to,
					className: "nav-link",
					activeProps: { className: "nav-link is-active" },
					activeOptions: { exact: link.to === "/" },
					onClick: () => setOpen(false),
					children: link.label
				}) }, link.to))
			})
		}) : null]
	});
}
/**
* Local simulation of the FastAPI pipeline described in SRS sections 4.2, 4.3
* and 8. It is deterministic and runs entirely in the browser: no model or
* vector store is contacted. The UI labels every result as simulated.
*/
var UNRESOLVED_DEPARTMENT = "Not determined";
var INTENT_RULES = [
	{
		intent: "Salary Deduction Dispute",
		department: "Finance & Payroll",
		keywords: [
			"salary",
			"deduct",
			"payroll",
			"payslip",
			"pay slip",
			"wage",
			"arrear",
			"increment",
			"reimbursement"
		]
	},
	{
		intent: "Refund Not Received",
		department: "Billing & Refunds",
		keywords: [
			"refund",
			"money back",
			"cancelled order",
			"credited",
			"not credited",
			"chargeback"
		]
	},
	{
		intent: "Billing Error",
		department: "Billing & Refunds",
		keywords: [
			"invoice",
			"overcharg",
			"charged twice",
			"double charge",
			"duplicate charge",
			"billing",
			"tariff",
			"wrong bill"
		]
	},
	{
		intent: "Portal / Access Failure",
		department: "IT Support",
		keywords: [
			"portal",
			"login",
			"log in",
			"password",
			"outage",
			"server",
			"crash",
			"error code",
			"timesheet",
			"not working",
			"website"
		]
	},
	{
		intent: "Workplace Grievance",
		department: "Human Resources",
		keywords: [
			"manager",
			"harass",
			"discriminat",
			"leave",
			"attendance",
			"shift",
			"colleague",
			"supervisor",
			"appraisal"
		]
	},
	{
		intent: "Facility Maintenance",
		department: "Facilities & Maintenance",
		keywords: [
			"leak",
			"water",
			"washroom",
			"electric",
			"light",
			"air condition",
			"lift",
			"elevator",
			"housekeeping",
			"garbage",
			"slippery"
		]
	},
	{
		intent: "Record / Certificate Request",
		department: "Public Records",
		keywords: [
			"certificate",
			"certified copy",
			"birth record",
			"passport",
			"licence",
			"license",
			"affidavit",
			"registrar"
		]
	}
];
function escapeRegExp(value) {
	return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
/** Prefix match on a word boundary so "deduct" also matches "deducted". */
function hasKeyword(text, keyword) {
	return new RegExp(`\\b${escapeRegExp(keyword)}`, "i").test(text);
}
function round(value, places = 2) {
	const factor = 10 ** places;
	return Math.round(value * factor) / factor;
}
var ENTITY_PATTERNS = [
	{
		type: "Amount",
		pattern: /(?:₹|rs\.?|inr)\s?([\d,]+(?:\.\d{1,2})?)/gi,
		normalize: (m) => `INR ${m[1].replace(/,/g, "")}`
	},
	{
		type: "Employee ID",
		pattern: /\bemp(?:loyee)?[\s-]?(?:id[\s:-]*)?([a-z]*\d{3,})\b/gi,
		normalize: (m) => `EMP-${m[1].toUpperCase()}`
	},
	{
		type: "Order ID",
		pattern: /\bord(?:er)?[\s-]?(?:id[\s:-]*)?([a-z0-9]{5,})\b/gi,
		normalize: (m) => `ORD-${m[1].toUpperCase()}`
	},
	{
		type: "Error Code",
		pattern: /\berr[\s-]?(\d{3,})\b/gi,
		normalize: (m) => `ERR-${m[1]}`
	},
	{
		type: "Email",
		pattern: /\b[\w.+-]+@[\w-]+\.[\w.]{2,}\b/g
	},
	{
		type: "Phone",
		pattern: /\b(?:\+91[\s-]?)?[6-9]\d{9}\b/g
	},
	{
		type: "Date",
		pattern: /\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b/g
	},
	{
		type: "Date",
		pattern: /\b(?:last|this|next|since)\s+(?:month|week|year|monday|tuesday|wednesday|thursday|friday|saturday|sunday|january|february|march|april|may|june|july|august|september|october|november|december)\b/gi
	},
	{
		type: "Date",
		pattern: /\b(?:january|february|march|april|may|june|july|august|september|october|november|december)\s+\d{1,2}(?:,\s?\d{4})?\b/gi
	},
	{
		type: "Location",
		pattern: /\b(?:block|floor|wing|gate|ward|sector)\s+[a-z0-9]{1,3}\b/gi
	}
];
function extractEntities(text) {
	const found = [];
	for (const { type, pattern, normalize } of ENTITY_PATTERNS) {
		const regex = new RegExp(pattern.source, pattern.flags);
		let match = regex.exec(text);
		while (match !== null) {
			const value = match[0].trim();
			const start = match.index;
			if (!found.some((e) => start < e.span[1] && start + value.length > e.span[0]) && value.length > 1) found.push({
				type,
				value,
				normalized: normalize ? normalize(match) : value,
				confidence: round(Math.min(.97, .72 + value.length / 60)),
				span: [start, start + value.length]
			});
			if (match.index === regex.lastIndex) regex.lastIndex += 1;
			match = regex.exec(text);
		}
	}
	return found.sort((a, b) => a.span[0] - b.span[0]);
}
function classify(text) {
	const scored = INTENT_RULES.map((rule) => ({
		rule,
		hits: rule.keywords.filter((keyword) => hasKeyword(text, keyword)).length
	})).sort((a, b) => b.hits - a.hits);
	const totalHits = scored.reduce((sum, item) => sum + item.hits, 0);
	if (totalHits === 0) return {
		intent: "Unclassified",
		department: UNRESOLVED_DEPARTMENT,
		confidence: .16,
		alternatives: [],
		modelVersion: CLASSIFIER_VERSION,
		taxonomyVersion: TAXONOMY_VERSION,
		ruleApplied: null,
		overriddenBy: null
	};
	const scoreOf = (hits) => {
		const share = hits / totalHits;
		const coverage = Math.min(1, hits / 4);
		return round(Math.min(.96, .35 * coverage + .65 * share));
	};
	const top = scored[0];
	let department = top.rule.department;
	let ruleApplied = null;
	if (hasKeyword(text, "err") && /\berr[\s-]?\d{3,}\b/i.test(text)) {
		department = "IT Support";
		ruleApplied = "RR-01 - an explicit error code routes to IT Support";
	} else if (hasKeyword(text, "harass") || hasKeyword(text, "discriminat") || hasKeyword(text, "safety")) {
		department = "Human Resources";
		ruleApplied = "RR-02 - harassment, discrimination or safety routes to HR";
	}
	return {
		intent: top.rule.intent,
		department,
		confidence: scoreOf(top.hits),
		alternatives: scored.slice(1).filter((item) => item.hits > 0).slice(0, 2).map((item) => ({
			intent: item.rule.intent,
			department: item.rule.department,
			confidence: scoreOf(item.hits)
		})),
		modelVersion: CLASSIFIER_VERSION,
		taxonomyVersion: TAXONOMY_VERSION,
		ruleApplied,
		overriddenBy: null
	};
}
var STOP_WORDS = /* @__PURE__ */ new Set([
	"a",
	"about",
	"after",
	"all",
	"also",
	"am",
	"an",
	"and",
	"any",
	"are",
	"as",
	"at",
	"be",
	"been",
	"but",
	"by",
	"can",
	"do",
	"for",
	"from",
	"has",
	"have",
	"i",
	"if",
	"in",
	"is",
	"it",
	"its",
	"me",
	"my",
	"no",
	"not",
	"of",
	"on",
	"only",
	"or",
	"shall",
	"she",
	"so",
	"still",
	"that",
	"the",
	"their",
	"then",
	"there",
	"they",
	"this",
	"to",
	"up",
	"was",
	"we",
	"were",
	"what",
	"when",
	"which",
	"who",
	"will",
	"with",
	"you",
	"your"
]);
function tokenize(text) {
	return (text.toLowerCase().match(/[a-z][a-z0-9-]{1,}/g) ?? []).filter((token) => !STOP_WORDS.has(token));
}
var CORPUS = POLICY_CHUNKS.map((chunk) => ({
	chunk,
	tokens: tokenize(chunk.text + " " + chunk.section)
}));
var AVG_LENGTH = CORPUS.reduce((sum, item) => sum + item.tokens.length, 0) / CORPUS.length;
var DOC_FREQUENCY = (() => {
	const frequency = /* @__PURE__ */ new Map();
	for (const item of CORPUS) for (const token of new Set(item.tokens)) frequency.set(token, (frequency.get(token) ?? 0) + 1);
	return frequency;
})();
function idf(token) {
	const df = DOC_FREQUENCY.get(token) ?? 0;
	return Math.log(1 + (CORPUS.length - df + .5) / (df + .5));
}
/** Stand-in for embedding similarity: cosine over binary term vectors. */
function denseScore(queryTokens, docTokens) {
	const query = new Set(queryTokens);
	const doc = new Set(docTokens);
	if (query.size === 0 || doc.size === 0) return 0;
	let shared = 0;
	for (const token of query) if (doc.has(token)) shared += 1;
	return round(Math.min(1, 2.6 * shared / Math.sqrt(query.size * doc.size)), 3);
}
/** BM25 over the same corpus, normalised into a 0-1 range for display. */
function bm25Score(queryTokens, docTokens) {
	const k1 = 1.5;
	const b = .75;
	let score = 0;
	for (const token of new Set(queryTokens)) {
		const tf = docTokens.filter((t) => t === token).length;
		if (tf === 0) continue;
		score += idf(token) * (tf * 2.5 / (tf + k1 * (.25 + b * docTokens.length / AVG_LENGTH)));
	}
	return round(Math.min(1, score / 9), 3);
}
function retrieve(text, department, policies) {
	const queryTokens = tokenize(text);
	const byId = new Map(policies.map((policy) => [policy.id, policy]));
	return CORPUS.filter(({ chunk }) => {
		const document = byId.get(chunk.documentId);
		if (!document || document.status !== "Active") return false;
		if (department !== "Not determined") return document.department === department;
		return true;
	}).map(({ chunk, tokens }) => {
		const document = byId.get(chunk.documentId);
		const dense = denseScore(queryTokens, tokens);
		const keyword = bm25Score(queryTokens, tokens);
		return {
			chunkId: chunk.id,
			documentId: chunk.documentId,
			documentTitle: document.title,
			version: document.version,
			effectiveDate: document.effectiveDate,
			department: document.department,
			section: chunk.section,
			page: chunk.page,
			snippet: chunk.text,
			denseScore: dense,
			keywordScore: keyword,
			hybridScore: round(CONFIG.denseWeight * dense + CONFIG.keywordWeight * keyword, 3)
		};
	}).filter((item) => item.hybridScore >= CONFIG.evidenceThreshold).sort((a, b) => b.hybridScore - a.hybridScore).slice(0, CONFIG.topK);
}
var NEXT_STEPS = {
	"Finance & Payroll": "Payroll will verify the wage register for the disputed month and confirm the correction in writing.",
	"Billing & Refunds": "Billing will trace the transaction with the payment gateway and share the reference for your bank.",
	"IT Support": "The service desk will log this as an incident and share the workaround or fix timeline.",
	"Human Resources": "Human Resources will complete the first review and contact you for any additional detail.",
	"Facilities & Maintenance": "A technician will be assigned to inspect the reported location and confirm completion with you.",
	"Public Records": "The records desk will check the application for completeness and list anything that is missing."
};
/** AI-07: reduce personal data before it is placed in a prompt or a draft. */
function maskPII(text) {
	return text.replace(/\b[\w.+-]+@[\w-]+\.[\w.]{2,}\b/g, "[email masked]").replace(/\b(?:\+91[\s-]?)?[6-9]\d{9}\b/g, "[phone masked]");
}
function firstName(fullName) {
	return fullName.trim().split(/\s+/)[0] || "Requester";
}
function generateDraft(input) {
	const { caseId, requesterName, department, evidence, now } = input;
	if (evidence.length === 0) return {
		text: [
			`A grounded draft could not be produced for ${caseId}.`,
			"",
			"No active policy section scored above the configured evidence threshold for this complaint, so any procedural commitment would be unsupported. This case requires manual handling by an administrator.",
			"",
			"Suggested administrator actions: confirm the correct department, ask the requester for the missing detail, or ingest the policy that covers this topic."
		].join("\n"),
		evidenceIds: [],
		generationModel: GENERATION_MODEL,
		grounding: "Insufficient Evidence",
		groundingNotes: ["No retrieved evidence cleared the evidence threshold, so generation abstained (FR-16).", "The draft contains no policy claim and cannot be approved for sending."],
		createdAt: now
	};
	const cited = evidence.slice(0, 3);
	const body = cited.map((item, index) => `As per ${item.documentTitle} (version ${item.version}, ${item.section}): "${item.snippet}" [${index + 1}]`);
	const sources = cited.map((item, index) => `[${index + 1}] ${item.documentTitle} - ${item.section}, page ${item.page} (version ${item.version}, effective ${item.effectiveDate})`);
	return {
		text: [
			`Dear ${firstName(requesterName)},`,
			"",
			`Thank you for contacting us. Your grievance has been registered as ${caseId} and routed to ${department} for review.`,
			"",
			...body.flatMap((line) => [line, ""]),
			NEXT_STEPS[department] ?? "The assigned department will review this case and respond on this reference.",
			"",
			`You can track the case with the reference ${caseId}.`,
			"",
			"Regards,",
			`${department} Support Desk`,
			"",
			"Sources",
			...sources
		].join("\n"),
		evidenceIds: cited.map((item) => item.chunkId),
		generationModel: GENERATION_MODEL,
		grounding: "Passed",
		groundingNotes: [
			`${cited.length} of ${cited.length} policy statements carry a citation (AI-05).`,
			"Every cited chunk belongs to an active policy version (FR-27).",
			`All evidence is owned by ${department}, which matches the routed department (FR-13).`,
			"Requester contact details were masked before generation (AI-07)."
		],
		createdAt: now
	};
}
function analyse(input) {
	const { caseId, requesterName, text, policies, now } = input;
	const classification = classify(maskPII(text));
	const entities = extractEntities(text);
	const evidence = retrieve(text, classification.department, policies);
	const draft = generateDraft({
		caseId,
		requesterName,
		department: classification.department,
		intent: classification.intent,
		evidence,
		now
	});
	const triageReasons = [];
	if (classification.confidence < CONFIG.confidenceThreshold) triageReasons.push(`Classifier confidence ${Math.round(classification.confidence * 100)}% is below the configured threshold of ${Math.round(CONFIG.confidenceThreshold * 100)}% (FR-10).`);
	if (classification.department === "Not determined") triageReasons.push("No department could be derived from the complaint text (FR-10).");
	if (draft.grounding === "Insufficient Evidence") triageReasons.push("No active policy evidence supports a grounded draft (FR-16, BR-03).");
	return {
		classification,
		entities,
		evidence,
		draft,
		status: triageReasons.length > 0 ? "Manual Triage" : "Pending Review",
		triageReasons
	};
}
var API_BASE_URL = "http://localhost:8000".replace(/\/$/, "");
var AUTH_TOKEN_KEY = "smarttracker_auth_token";
function getAuthToken() {
	if (typeof window === "undefined") return null;
	try {
		return window.localStorage.getItem(AUTH_TOKEN_KEY);
	} catch {
		return null;
	}
}
function setAuthToken(token) {
	if (typeof window === "undefined") return;
	try {
		if (token) window.localStorage.setItem(AUTH_TOKEN_KEY, token);
		else window.localStorage.removeItem(AUTH_TOKEN_KEY);
	} catch {}
}
function getAuthUser() {
	const token = getAuthToken();
	if (!token) return null;
	try {
		const parts = token.split(".");
		if (parts.length !== 3) return null;
		const payload = JSON.parse(atob(parts[1]));
		return {
			id: Number(payload.sub),
			role: String(payload.role)
		};
	} catch {
		return null;
	}
}
function getBackendImageUrl(relativePath) {
	if (!relativePath) return null;
	if (relativePath.startsWith("http://") || relativePath.startsWith("https://")) return relativePath;
	return `${API_BASE_URL}/${relativePath.replace(/^\/+/, "")}`;
}
function errorMessage(status, body) {
	if (body && typeof body === "object" && "detail" in body && typeof body.detail === "string") return body.detail;
	return `API request failed (${status})`;
}
async function request(path, init) {
	const token = getAuthToken();
	const headers = {
		Accept: "application/json",
		...typeof FormData !== "undefined" && init?.body instanceof FormData ? {} : init?.body ? { "Content-Type": "application/json" } : {},
		...init?.headers
	};
	if (token && !headers["Authorization"]) headers["Authorization"] = `Bearer ${token}`;
	const response = await fetch(`${API_BASE_URL}${path}`, {
		...init,
		signal: init?.signal ?? AbortSignal.timeout(12e4),
		headers
	});
	const body = await response.json().catch(() => null);
	if (!response.ok) throw new Error(errorMessage(response.status, body));
	return body;
}
function mapStatus(status) {
	switch (status) {
		case "submitted": return "Submitted";
		case "processing": return "AI Analysis";
		case "awaiting_review": return "Pending Review";
		case "assigned": return "Assigned to Department";
		case "in_progress": return "In Progress";
		case "verification": return "Verification";
		case "completed":
		case "resolved": return "Resolved";
		case "rejected": return "Rejected";
		default: return "Submitted";
	}
}
function mapEntities(raw) {
	if (!raw) return [];
	try {
		const parsed = JSON.parse(raw);
		const entities = [];
		if (Array.isArray(parsed)) return parsed;
		if (Array.isArray(parsed.order_ids)) for (const orderId of parsed.order_ids) entities.push({
			type: "Order ID",
			value: String(orderId),
			normalized: String(orderId),
			confidence: 1,
			span: [0, 0]
		});
		if (parsed.account_id) entities.push({
			type: "Employee ID",
			value: String(parsed.account_id),
			normalized: String(parsed.account_id),
			confidence: 1,
			span: [0, 0]
		});
		if (parsed.error_code) entities.push({
			type: "Error Code",
			value: String(parsed.error_code),
			normalized: String(parsed.error_code),
			confidence: 1,
			span: [0, 0]
		});
		return entities;
	} catch {
		return [];
	}
}
function mapPriority(status) {
	return status === "high" ? "High" : status === "low" ? "Low" : "Medium";
}
function mapComplaint(row) {
	const classification = row.category || row.department ? {
		intent: row.category ?? "other",
		department: row.department ?? "other",
		confidence: row.confidence_score ?? 0,
		alternatives: [],
		modelVersion: "Gemini",
		taxonomyVersion: "Phase 2",
		ruleApplied: null,
		overriddenBy: null
	} : null;
	return {
		id: String(row.id),
		requesterName: `User ${row.user_id}`,
		contact: "",
		channel: "Web",
		language: "English",
		text: row.complaint_text,
		attachments: [],
		priority: mapPriority(row.status),
		status: mapStatus(row.status),
		submittedAt: row.created_at,
		updatedAt: row.updated_at,
		assignedDepartment: row.department,
		location: row.location_type != null ? {
			type: row.location_type,
			latitude: row.latitude,
			longitude: row.longitude,
			manualAddress: row.manual_address
		} : null,
		classification,
		entities: mapEntities(row.extracted_entities),
		evidence: [],
		aiDraft: row.ai_draft_response ? {
			text: row.ai_draft_response,
			evidenceIds: [],
			generationModel: "Gemini",
			grounding: "Passed",
			groundingNotes: [],
			createdAt: row.updated_at
		} : null,
		editedDraft: null,
		resolution: null,
		closureReason: null,
		duplicateOf: null,
		comments: [],
		audit: [],
		imagePath: row.image_path ?? null,
		wasteType: row.waste_type ?? null,
		severity: row.severity ?? null,
		aiReasoning: row.ai_reasoning ?? null
	};
}
async function login(payload) {
	const result = await request("/auth/login", {
		method: "POST",
		body: JSON.stringify(payload)
	});
	if (result.access_token) setAuthToken(result.access_token);
	return result;
}
async function submitWasteComplaint(formData) {
	return mapComplaint(await request("/complaints", {
		method: "POST",
		body: formData
	}));
}
async function getComplaint(complaintId) {
	return mapComplaint(await request(`/complaints/${complaintId}`));
}
async function getAdminQueue() {
	return request("/admin/queue");
}
async function approveComplaint(complaintId, payload) {
	return request(`/admin/responses/${complaintId}/approve`, {
		method: "POST",
		body: JSON.stringify({ final_response: payload.final_response })
	});
}
async function listCleaners() {
	return request("/admin/cleaners");
}
async function reviewWasteComplaint(complaintId, payload) {
	return request(`/admin/complaints/${complaintId}/review`, {
		method: "POST",
		body: JSON.stringify(payload)
	});
}
async function listCleanerTasks() {
	return request("/cleaner/tasks");
}
async function startCleanerTask(taskId) {
	return request(`/cleaner/tasks/${taskId}/start`, { method: "POST" });
}
async function uploadCleanupProof(taskId, formData) {
	return request(`/cleaner/tasks/${taskId}/proof`, {
		method: "POST",
		body: formData
	});
}
async function listCleanupTasks() {
	return request("/admin/cleanup-tasks");
}
async function verifyCleanupTask(taskId, payload) {
	return request(`/admin/cleanup-tasks/${taskId}/verify`, {
		method: "POST",
		body: JSON.stringify(payload)
	});
}
/**
* Client-side store standing in for the FastAPI backend. State is kept in a
* single object so the server render and the first client render match; the
* browser copy is rehydrated from localStorage after mount.
*/
var STORAGE_KEY = "smarttracker.state.v2";
/** Fixed reference time used for the server render and the seeded data. */
var SEED_NOW = "2026-02-10T06:00:00.000Z";
var requestCounter = 0;
function nextRequestId() {
	requestCounter += 1;
	return `req-${String(requestCounter).padStart(5, "0")}`;
}
function auditEvent(at, actor, action, detail, index) {
	return {
		id: `AE-${index}`,
		at,
		actor,
		action,
		detail,
		requestId: nextRequestId()
	};
}
function buildSeedState() {
	const policies = POLICY_DOCUMENTS;
	return {
		cases: SEED_CASES.map((seed) => {
			const analysis = analyse({
				caseId: seed.id,
				requesterName: seed.requesterName,
				text: seed.text,
				policies,
				now: seed.submittedAt
			});
			const audit = [
				auditEvent(seed.submittedAt, seed.requesterName, "Complaint submitted", `Channel: ${seed.channel}`, 1),
				auditEvent(seed.submittedAt, "System", "AI analysis completed", `Intent: ${analysis.classification.intent}; department: ${analysis.classification.department}; confidence: ${analysis.classification.confidence}`, 2),
				auditEvent(seed.submittedAt, "System", `Status set to ${analysis.status}`, analysis.triageReasons.join(" ") || null, 3)
			];
			const record = {
				id: seed.id,
				requesterName: seed.requesterName,
				contact: seed.contact,
				channel: seed.channel,
				language: "English",
				text: seed.text,
				attachments: [],
				priority: seed.priority,
				status: analysis.status,
				submittedAt: seed.submittedAt,
				updatedAt: seed.submittedAt,
				assignedDepartment: null,
				location: null,
				classification: analysis.classification,
				entities: analysis.entities,
				evidence: analysis.evidence,
				aiDraft: analysis.draft,
				editedDraft: null,
				resolution: null,
				closureReason: null,
				duplicateOf: null,
				comments: [],
				audit
			};
			const advance = seed.advance;
			if (!advance) return record;
			const at = advance.approvedResponse?.sentAt ?? seed.submittedAt;
			if (advance.assignTo) {
				record.assignedDepartment = advance.assignTo;
				record.audit.push(auditEvent(at, "A. Patil", "Assigned to department", advance.assignTo, record.audit.length + 1));
			}
			if (advance.approvedResponse && record.aiDraft) {
				record.resolution = {
					text: record.aiDraft.text,
					approver: advance.approvedResponse.approver,
					sentAt: advance.approvedResponse.sentAt
				};
				record.audit.push(auditEvent(advance.approvedResponse.sentAt, advance.approvedResponse.approver, "Response approved and sent", "Draft approved without edits", record.audit.length + 1));
			}
			if (advance.status) {
				record.status = advance.status;
				record.audit.push(auditEvent(at, "A. Patil", `Status set to ${advance.status}`, null, record.audit.length + 1));
			}
			if (advance.comment) record.comments.push({
				id: `CMT-${record.id}-1`,
				at: advance.comment.at,
				author: advance.comment.author,
				text: advance.comment.text
			});
			record.updatedAt = at;
			return record;
		}),
		policies,
		session: SESSIONS[0],
		now: SEED_NOW,
		hydrated: false
	};
}
var state = buildSeedState();
var listeners = /* @__PURE__ */ new Set();
function emit() {
	for (const listener of listeners) listener();
}
function set(updater) {
	state = updater(state);
	emit();
	persist();
}
function persist() {
	if (typeof window === "undefined" || !state.hydrated) return;
	try {
		window.localStorage.setItem(STORAGE_KEY, JSON.stringify({
			cases: state.cases,
			policies: state.policies
		}));
	} catch {}
}
function subscribe(listener) {
	listeners.add(listener);
	return () => listeners.delete(listener);
}
function getSnapshot() {
	return state;
}
function useAppState() {
	return (0, import_react.useSyncExternalStore)(subscribe, getSnapshot, getSnapshot);
}
/** Called once from the root component, after the first client render. */
function hydrateStore() {
	if (state.hydrated || typeof window === "undefined") return;
	let restored = null;
	try {
		const raw = window.localStorage.getItem(STORAGE_KEY);
		if (raw) restored = JSON.parse(raw);
	} catch {
		restored = null;
	}
	state = {
		...state,
		cases: restored?.cases ?? state.cases,
		policies: restored?.policies ?? state.policies,
		now: (/* @__PURE__ */ new Date()).toISOString(),
		hydrated: true
	};
	emit();
}
function resetStore() {
	state = {
		...buildSeedState(),
		now: (/* @__PURE__ */ new Date()).toISOString(),
		hydrated: true
	};
	emit();
	persist();
}
function findCase(id) {
	const wanted = id.trim().toUpperCase();
	return state.cases.find((item) => item.id.toUpperCase() === wanted) ?? null;
}
/** UR-05: a department officer may only read their own department's cases. */
function isVisible(item, session) {
	if (session.departments === null) return true;
	const department = item.assignedDepartment ?? item.classification?.department;
	return department === void 0 ? false : session.departments.includes(department);
}
function activeDraft(item) {
	return item.editedDraft ?? item.aiDraft?.text ?? "";
}
function touch(item, at, actor, action, detail) {
	return {
		...item,
		updatedAt: at,
		audit: [...item.audit, auditEvent(at, actor, action, detail, item.audit.length + 1)]
	};
}
function updateCase(id, updater) {
	set((current) => ({
		...current,
		cases: current.cases.map((item) => item.id === id ? updater(item) : item)
	}));
}
/** FR-11: authorised override of the AI classification. */
function overrideClassification(id, next) {
	const at = (/* @__PURE__ */ new Date()).toISOString();
	const actor = state.session.name;
	updateCase(id, (item) => {
		if (!item.classification) return item;
		const before = `${item.classification.intent} / ${item.classification.department}`;
		return touch({
			...item,
			classification: {
				...item.classification,
				intent: next.intent,
				department: next.department,
				overriddenBy: actor
			}
		}, at, actor, "Classification overridden", `${before} -> ${next.intent} / ${next.department}. Reason: ${next.reason}`);
	});
}
/** FR-19: the edited draft is stored separately from the AI original. */
function saveDraftEdit(id, text) {
	const at = (/* @__PURE__ */ new Date()).toISOString();
	updateCase(id, (item) => touch({
		...item,
		editedDraft: text
	}, at, state.session.name, "Draft edited", "Original AI draft retained"));
}
/** FR-21: reassign with a mandatory reason (BR-02). */
function reassign(id, department, reason) {
	const at = (/* @__PURE__ */ new Date()).toISOString();
	const actor = state.session.name;
	updateCase(id, (item) => touch({
		...item,
		assignedDepartment: department,
		status: item.status === "Manual Triage" || item.status === "Pending Review" ? "Assigned to Department" : item.status
	}, at, actor, "Case reassigned", `To ${department}. Reason: ${reason}`));
}
function escalate(id, reason) {
	const at = (/* @__PURE__ */ new Date()).toISOString();
	updateCase(id, (item) => touch({
		...item,
		status: "Escalated"
	}, at, state.session.name, "Case escalated", reason));
}
function reject(id, reason) {
	const at = (/* @__PURE__ */ new Date()).toISOString();
	updateCase(id, (item) => touch({
		...item,
		status: "Rejected",
		closureReason: reason
	}, at, state.session.name, "Case rejected as invalid", reason));
}
function markDuplicate(id, originalId, reason) {
	const at = (/* @__PURE__ */ new Date()).toISOString();
	updateCase(id, (item) => touch({
		...item,
		status: "Duplicate",
		duplicateOf: originalId.toUpperCase(),
		closureReason: reason
	}, at, state.session.name, "Marked as duplicate", `Linked to ${originalId.toUpperCase()}. Reason: ${reason}`));
}
/** FR-22 / BR-06: only workflow-permitted transitions are applied. */
function setStatus(id, next, note) {
	const target = findCase(id);
	if (!target || !canTransition(target.status, next)) return false;
	const at = (/* @__PURE__ */ new Date()).toISOString();
	updateCase(id, (item) => touch({
		...item,
		status: next
	}, at, state.session.name, `Status set to ${next}`, note || null));
	return true;
}
function addComment(id, text) {
	const at = (/* @__PURE__ */ new Date()).toISOString();
	const author = state.session.name;
	updateCase(id, (item) => ({
		...item,
		comments: [...item.comments, {
			id: `CMT-${item.id}-${item.comments.length + 1}`,
			at,
			author,
			text
		}],
		updatedAt: at
	}));
}
function setSession(session) {
	set((current) => ({
		...current,
		session
	}));
}
/** FR-25, FR-26: ingest, then report what the extraction step produced. */
function ingestPolicy(input) {
	const at = (/* @__PURE__ */ new Date()).toISOString();
	const id = `DOC-${String(state.policies.length + 1).padStart(3, "0")}`;
	const duplicate = state.policies.some((policy) => policy.title.toLowerCase() === input.title.toLowerCase() && policy.version === input.version);
	const ingestion = {
		chunks: Math.max(1, input.pages * 3),
		unreadablePages: [],
		warnings: [...duplicate ? [`A document with the title "${input.title}" and version ${input.version} already exists.`] : [], "Chunk text is not searchable in this demo build: no vector store or BM25 index is connected."]
	};
	const record = {
		id,
		title: input.title,
		owner: input.owner,
		department: input.department,
		policyType: input.policyType,
		jurisdiction: input.jurisdiction,
		version: input.version,
		effectiveDate: input.effectiveDate,
		status: "Pending Approval",
		pages: input.pages,
		lastUpdated: at.slice(0, 10),
		supersedes: input.supersedes,
		ingestion
	};
	set((current) => ({
		...current,
		policies: [record, ...current.policies]
	}));
	return record;
}
function activatePolicy(id) {
	const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
	set((current) => {
		const target = current.policies.find((policy) => policy.id === id);
		if (!target) return current;
		return {
			...current,
			policies: current.policies.map((policy) => {
				if (policy.id === id) return {
					...policy,
					status: "Active",
					lastUpdated: today
				};
				if (target.supersedes && policy.id === target.supersedes) return {
					...policy,
					status: "Retired",
					lastUpdated: today
				};
				return policy;
			})
		};
	});
}
function retirePolicy(id) {
	set((current) => ({
		...current,
		policies: current.policies.map((policy) => policy.id === id ? {
			...policy,
			status: "Retired",
			lastUpdated: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10)
		} : policy)
	}));
}
var styles_default = "/assets/styles-DKjk-iiK.css";
var THEME_INIT_SCRIPT = `(function(){try{var stored=window.localStorage.getItem('theme');var mode=(stored==='light'||stored==='dark'||stored==='auto')?stored:'auto';var prefersDark=window.matchMedia('(prefers-color-scheme: dark)').matches;var resolved=mode==='auto'?(prefersDark?'dark':'light'):mode;var root=document.documentElement;root.classList.remove('light','dark');root.classList.add(resolved);if(mode==='auto'){root.removeAttribute('data-theme')}else{root.setAttribute('data-theme',mode)}root.style.colorScheme=resolved;}catch(e){}})();`;
var Route$11 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "SmartTracker AI — Grievance Routing & Resolution" },
			{
				name: "description",
				content: "Submit a grievance in plain language, track its status, and let administrators review AI classification, policy evidence and grounded draft responses."
			}
		],
		links: [{
			rel: "stylesheet",
			href: styles_default
		}]
	}),
	shellComponent: RootDocument
});
function RootDocument({ children }) {
	(0, import_react.useEffect)(hydrateStore, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("head", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", { dangerouslySetInnerHTML: { __html: THEME_INIT_SCRIPT } }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "flex min-h-screen flex-col font-sans antialiased",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "skip-link",
					href: "#main",
					children: "Skip to main content"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
				children,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	});
}
var $$splitComponentImporter$10 = () => import("./routes-dyCT_REa.mjs");
var Route$10 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./admin-BPAkCfe1.mjs");
var Route$9 = createFileRoute("/admin")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./cleaner-BzEnumxZ.mjs");
var Route$8 = createFileRoute("/cleaner")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./guide-Bbd6pfuz.mjs");
var Route$7 = createFileRoute("/guide")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
/** FR-29: identify a supported document or service from a plain-language query. */
var $$splitComponentImporter$6 = () => import("./login-BDE_LH2D.mjs");
var Route$6 = createFileRoute("/login")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./submit-Mh_juzYH.mjs");
var Route$5 = createFileRoute("/submit")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./track-U5OBSLnr.mjs");
var Route$4 = createFileRoute("/track")({
	validateSearch: (search) => typeof search.id === "string" && search.id ? { id: search.id } : {},
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./admin.index-CTAIuALB.mjs");
var Route$3 = createFileRoute("/admin/")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./admin.knowledge-BXSYy9Cu.mjs");
var Route$2 = createFileRoute("/admin/knowledge")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./admin.verification-CJYkY4t7.mjs");
var Route$1 = createFileRoute("/admin/verification")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./admin.cases._caseId-_zZdzzIU.mjs");
var Route = createFileRoute("/admin/cases/$caseId")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var IndexRoute = Route$10.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$11
});
var AdminRoute = Route$9.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => Route$11
});
var CleanerRoute = Route$8.update({
	id: "/cleaner",
	path: "/cleaner",
	getParentRoute: () => Route$11
});
var GuideRoute = Route$7.update({
	id: "/guide",
	path: "/guide",
	getParentRoute: () => Route$11
});
var LoginRoute = Route$6.update({
	id: "/login",
	path: "/login",
	getParentRoute: () => Route$11
});
var SubmitRoute = Route$5.update({
	id: "/submit",
	path: "/submit",
	getParentRoute: () => Route$11
});
var TrackRoute = Route$4.update({
	id: "/track",
	path: "/track",
	getParentRoute: () => Route$11
});
var AdminIndexRoute = Route$3.update({
	id: "/",
	path: "/",
	getParentRoute: () => AdminRoute
});
var AdminRouteChildren = {
	AdminKnowledgeRoute: Route$2.update({
		id: "/knowledge",
		path: "/knowledge",
		getParentRoute: () => AdminRoute
	}),
	AdminVerificationRoute: Route$1.update({
		id: "/verification",
		path: "/verification",
		getParentRoute: () => AdminRoute
	}),
	AdminIndexRoute,
	AdminCasesCaseIdRoute: Route.update({
		id: "/cases/$caseId",
		path: "/cases/$caseId",
		getParentRoute: () => AdminRoute
	})
};
var rootRouteChildren = {
	IndexRoute,
	AdminRoute: AdminRoute._addFileChildren(AdminRouteChildren),
	CleanerRoute,
	GuideRoute,
	LoginRoute,
	SubmitRoute,
	TrackRoute
};
var routeTree = Route$11._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		scrollRestoration: true,
		defaultPreload: "intent",
		defaultPreloadStaleTime: 0
	});
}
//#endregion
export { startCleanerTask as A, getBackendImageUrl as C, listCleanupTasks as D, listCleaners as E, uploadCleanupProof as M, verifyCleanupTask as N, login as O, getAuthUser as S, listCleanerTasks as T, setSession as _, activeDraft as a, approveComplaint as b, ingestPolicy as c, overrideClassification as d, reassign as f, saveDraftEdit as g, retirePolicy as h, activatePolicy as i, submitWasteComplaint as j, reviewWasteComplaint as k, isVisible as l, resetStore as m, Route as n, addComment as o, reject as p, Route$4 as r, escalate as s, router_exports as t, markDuplicate as u, setStatus as v, getComplaint as w, getAdminQueue as x, useAppState as y };
