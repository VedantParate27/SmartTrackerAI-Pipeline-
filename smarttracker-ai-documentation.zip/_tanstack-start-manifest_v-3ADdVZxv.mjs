//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-3ADdVZxv.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/Admin/OneDrive/Desktop/smarttracker-ai/frontend/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/cleaner",
			"/guide",
			"/login",
			"/submit",
			"/track"
		],
		preloads: [
			"/assets/index-B03xIXTO.js",
			"/assets/taxonomy-DEneqMO4.js",
			"/assets/link-oqsraY1L.js",
			"/assets/Match-DqwsLDrL.js",
			"/assets/matchContext-Dg3ft267.js",
			"/assets/useRouter-6z2K6iyO.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B03xIXTO.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/Admin/OneDrive/Desktop/smarttracker-ai/frontend/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BGtZijZ5.js", "/assets/ui-CwMINNqo.js"]
	},
	"/admin": {
		filePath: "C:/Users/Admin/OneDrive/Desktop/smarttracker-ai/frontend/src/routes/admin.tsx",
		children: [
			"/admin/knowledge",
			"/admin/verification",
			"/admin/",
			"/admin/cases/$caseId"
		],
		preloads: ["/assets/admin-yvWRI4_M.js"]
	},
	"/cleaner": {
		filePath: "C:/Users/Admin/OneDrive/Desktop/smarttracker-ai/frontend/src/routes/cleaner.tsx",
		children: void 0,
		preloads: ["/assets/cleaner-M_D46tNc.js", "/assets/ui-CwMINNqo.js"]
	},
	"/guide": {
		filePath: "C:/Users/Admin/OneDrive/Desktop/smarttracker-ai/frontend/src/routes/guide.tsx",
		children: void 0,
		preloads: ["/assets/guide-c0ZewEr1.js", "/assets/ui-CwMINNqo.js"]
	},
	"/login": {
		filePath: "C:/Users/Admin/OneDrive/Desktop/smarttracker-ai/frontend/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-ANBvaU0N.js", "/assets/ui-CwMINNqo.js"]
	},
	"/submit": {
		filePath: "C:/Users/Admin/OneDrive/Desktop/smarttracker-ai/frontend/src/routes/submit.tsx",
		children: void 0,
		preloads: ["/assets/submit-BjdttF_b.js", "/assets/ui-CwMINNqo.js"]
	},
	"/track": {
		filePath: "C:/Users/Admin/OneDrive/Desktop/smarttracker-ai/frontend/src/routes/track.tsx",
		children: void 0,
		preloads: ["/assets/track-Fp8frTb-.js", "/assets/ui-CwMINNqo.js"]
	},
	"/admin/knowledge": {
		filePath: "C:/Users/Admin/OneDrive/Desktop/smarttracker-ai/frontend/src/routes/admin.knowledge.tsx",
		children: void 0,
		preloads: ["/assets/admin.knowledge-BziXiG96.js", "/assets/ui-CwMINNqo.js"]
	},
	"/admin/verification": {
		filePath: "C:/Users/Admin/OneDrive/Desktop/smarttracker-ai/frontend/src/routes/admin.verification.tsx",
		children: void 0,
		preloads: ["/assets/admin.verification-CJd0f8gA.js", "/assets/ui-CwMINNqo.js"]
	},
	"/admin/": {
		filePath: "C:/Users/Admin/OneDrive/Desktop/smarttracker-ai/frontend/src/routes/admin.index.tsx",
		children: void 0,
		preloads: ["/assets/admin.index-CLaX-KXY.js", "/assets/ui-CwMINNqo.js"]
	},
	"/admin/cases/$caseId": {
		filePath: "C:/Users/Admin/OneDrive/Desktop/smarttracker-ai/frontend/src/routes/admin.cases.$caseId.tsx",
		children: void 0,
		preloads: ["/assets/admin.cases._caseId-B8tche7S.js", "/assets/ui-CwMINNqo.js"]
	}
} });
//#endregion
export { tsrStartManifest };
