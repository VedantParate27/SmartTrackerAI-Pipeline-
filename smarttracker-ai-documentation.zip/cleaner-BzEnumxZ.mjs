import { r as __toESM } from "../_runtime.mjs";
import { R as require_react, _ as Link, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as startCleanerTask, C as getBackendImageUrl, M as uploadCleanupProof, T as listCleanerTasks } from "./router-DxxzZ2Qy.mjs";
import { a as Field, c as StatusPill, t as Callout } from "./ui-DYNAo6oe.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cleaner-BzEnumxZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CleanerPortalPage() {
	const [tasks, setTasks] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [error, setError] = (0, import_react.useState)(null);
	const [actionMessage, setActionMessage] = (0, import_react.useState)(null);
	const [selectedFileMap, setSelectedFileMap] = (0, import_react.useState)({});
	const [uploadingTaskId, setUploadingTaskId] = (0, import_react.useState)(null);
	const [uploadResultMap, setUploadResultMap] = (0, import_react.useState)({});
	const fetchTasks = async () => {
		setLoading(true);
		setError(null);
		try {
			const data = await listCleanerTasks();
			setTasks(data);
		} catch (err) {
			setError(err?.message || "Failed to load cleaner tasks. Make sure you are signed in as a cleaner.");
		} finally {
			setLoading(false);
		}
	};
	(0, import_react.useEffect)(() => {
		fetchTasks();
	}, []);
	const handleStart = async (taskId) => {
		setActionMessage(null);
		try {
			await startCleanerTask(taskId);
			setActionMessage(`Task #${taskId} marked as started (In Progress).`);
			await fetchTasks();
		} catch (err) {
			setError(err?.message || "Failed to start task.");
		}
	};
	const handleFileChange = (taskId, file) => {
		setSelectedFileMap((prev) => ({
			...prev,
			[taskId]: file
		}));
	};
	const handleUploadProof = async (taskId) => {
		const file = selectedFileMap[taskId];
		if (!file) {
			setError("Please select an image file to upload as proof.");
			return;
		}
		setUploadingTaskId(taskId);
		setError(null);
		setActionMessage(null);
		try {
			const formData = new FormData();
			formData.append("image", file);
			const result = await uploadCleanupProof(taskId, formData);
			setUploadResultMap((prev) => ({
				...prev,
				[taskId]: result
			}));
			setActionMessage(`Cleanup proof uploaded for Task #${taskId}! AI verification confidence: ${(result.ai_verification.confidence * 100).toFixed(0)}%`);
			await fetchTasks();
		} catch (err) {
			setError(err?.message || "Failed to upload cleanup proof.");
		} finally {
			setUploadingTaskId(null);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "main",
		className: "wrap page max-w-4xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: "Field Operations"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 text-2xl font-extrabold sm:text-3xl",
				children: "Cleaner Task Portal"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm muted",
				children: "View assigned cleanup tasks, start work, and upload completion proof images."
			}),
			actionMessage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, {
					tone: "ok",
					title: "Action Completed",
					children: actionMessage
				})
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Callout, {
					tone: "danger",
					title: "Error",
					children: [
						error,
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/login",
							className: "underline font-semibold",
							children: "Sign in as Cleaner"
						})
					]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex justify-between items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "text-lg font-bold",
					children: [
						"Assigned Tasks (",
						tasks.length,
						")"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-sm btn-quiet",
					onClick: fetchTasks,
					children: "Refresh Tasks"
				})]
			}),
			loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 card card-pad text-center muted",
				children: "Loading assigned tasks..."
			}) : tasks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 card card-pad text-center muted",
				children: "No cleanup tasks currently assigned to your account."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 grid gap-4",
				children: tasks.map((task) => {
					const proofResult = uploadResultMap[task.id];
					const selectedFile = selectedFileMap[task.id];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "card card-pad grid gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-start justify-between gap-2 border-b border-(--line) pb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "kicker",
									children: [
										"Task #",
										task.id,
										" · Ref: ",
										task.tracking_id
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "text-base font-extrabold mt-0.5",
									children: ["Complaint #", task.complaint_id]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "pill",
										children: ["Task: ", task.status]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: task.complaint_status })]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-3 sm:grid-cols-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "kicker",
										children: "Description"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "m-0 text-(--fg)",
										children: task.complaint_text
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-3 grid grid-cols-2 gap-2 text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "kicker",
											children: "Waste Type"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "m-0 font-semibold capitalize",
											children: task.waste_type ?? "N/A"
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "kicker",
											children: "Severity"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "m-0 font-semibold capitalize",
											children: task.severity ?? "Normal"
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 text-xs muted",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "kicker",
											children: "Location"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "m-0",
											children: task.location_type === "gps" ? `GPS (${task.latitude?.toFixed(4)}, ${task.longitude?.toFixed(4)})` : task.manual_address ?? "Not specified"
										})]
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: task.image_path ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "kicker",
									children: "Initial Waste Image"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-1 rounded overflow-hidden border border-(--line) max-w-xs",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: getBackendImageUrl(task.image_path) ?? void 0,
										alt: "Initial waste complaint",
										className: "w-full h-auto max-h-36 object-cover"
									})
								})] }) : null })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 pt-3 border-t border-(--line) flex flex-wrap items-center justify-between gap-3",
								children: [
									task.status === "assigned" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "btn btn-primary btn-sm",
										onClick: () => handleStart(task.id),
										children: "Start Task"
									}) : null,
									task.status === "in_progress" || task.status === "assigned" || task.status === "rework_required" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex-1 max-w-lg bg-(--surface-2) p-3 rounded-lg grid gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Upload Completion Proof Image",
											htmlFor: `proof-${task.id}`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												id: `proof-${task.id}`,
												type: "file",
												accept: "image/jpeg,image/png,image/webp",
												className: "input text-xs",
												onChange: (e) => handleFileChange(task.id, e.target.files?.[0] ?? null)
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "btn btn-primary btn-sm",
											disabled: !selectedFile || uploadingTaskId === task.id,
											onClick: () => handleUploadProof(task.id),
											children: uploadingTaskId === task.id ? "Uploading..." : "Submit Cleanup Proof"
										})]
									}) : null,
									proofResult ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "w-full bg-(--ok-surface) p-3 rounded-lg text-xs space-y-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-bold text-(--ok-fg)",
												children: "AI Cleanup Verification Result"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
												"Task status: ",
												proofResult.task_status,
												" | Complaint status: ",
												proofResult.complaint_status
											] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
												"Usable: ",
												proofResult.ai_verification.after_image_usable ? "Yes" : "No",
												" | Clean: ",
												proofResult.ai_verification.cleanup_appears_complete ? "Yes" : "No",
												" | Confidence: ",
												(proofResult.ai_verification.confidence * 100).toFixed(0),
												"%"
											] })
										]
									}) : null
								]
							})
						]
					}, task.id);
				})
			})
		]
	});
}
//#endregion
export { CleanerPortalPage as component };
