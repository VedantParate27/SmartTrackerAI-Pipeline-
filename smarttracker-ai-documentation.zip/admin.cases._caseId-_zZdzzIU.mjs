import { r as __toESM } from "../_runtime.mjs";
import { a as EMBEDDING_MODEL, i as DEPARTMENTS, p as can, r as CONFIG, t as ALLOWED_TRANSITIONS } from "./taxonomy-tJaYsAgr.mjs";
import { R as require_react, _ as Link, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as getBackendImageUrl, E as listCleaners, a as activeDraft, b as approveComplaint, d as overrideClassification, f as reassign, g as saveDraftEdit, k as reviewWasteComplaint, l as isVisible, n as Route, o as addComment, p as reject, s as escalate, u as markDuplicate, v as setStatus, w as getComplaint, y as useAppState } from "./router-DxxzZ2Qy.mjs";
import { c as StatusPill, d as formatBytes, f as formatDate, i as EmptyState, m as percent, n as ConfidenceMeter, o as PriorityPill, p as formatDateTime, s as SectionCard, t as Callout, u as formatAge } from "./ui-DYNAo6oe.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.cases._caseId-_zZdzzIU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CaseDetailPage() {
	const { caseId } = Route.useParams();
	const { session, now } = useAppState();
	const [item, setItem] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		setLoading(true);
		getComplaint(caseId).then((complaint) => {
			setItem(complaint);
		}).catch((error) => {
			console.error("Failed to load complaint:", error);
			setItem(null);
		}).finally(() => {
			setLoading(false);
		});
	}, [caseId]);
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Loading case..." });
	if (!item) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Callout, {
		tone: "warn",
		title: "Case not found",
		children: [
			"No case is stored against ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mono",
				children: caseId
			}),
			".",
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/admin",
				children: "Back to the queue"
			}),
			"."
		]
	});
	if (!isVisible(item, session)) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Callout, {
		tone: "danger",
		title: "Not authorised",
		children: [
			"This case is not routed to your department, so its contents are not available to you. ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/admin",
				children: "Back to the queue"
			}),
			"."
		]
	});
	const draftReady = item.status === "Pending Review" || item.status === "Manual Triage";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/admin",
				className: "text-sm no-underline",
				children: "← Back to queue"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "card card-pad",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "kicker",
							children: "Grievance"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mono mt-0.5 text-lg font-extrabold",
							children: item.id
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: item.status }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriorityPill, { priority: item.priority })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-4 grid grid-cols-2 gap-3 text-sm lg:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "kicker",
							children: "Requester"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "m-0",
							children: item.requesterName
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "kicker",
								children: "Contact"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "m-0 truncate",
								children: item.contact
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "kicker",
							children: "Submitted"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "m-0",
							children: formatDateTime(item.submittedAt)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "kicker",
							children: "Age"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "m-0",
							children: formatAge(item.submittedAt, now)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "kicker",
							children: "Channel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "m-0",
							children: item.channel
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "kicker",
							children: "Language"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "m-0",
							children: item.language
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "kicker",
							children: "Assigned to"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "m-0",
							children: item.assignedDepartment ?? "Not assigned"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "kicker",
								children: "Location"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "m-0 truncate",
								children: item.location?.type === "gps" ? `${item.location.latitude?.toFixed(5)}, ${item.location.longitude?.toFixed(5)}` : item.location?.type === "manual" ? item.location.manualAddress : "Not provided"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "kicker",
							children: "Last updated"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "m-0",
							children: formatDateTime(item.updatedAt)
						})] })
					]
				})]
			}),
			item.status === "Manual Triage" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, {
				tone: "warn",
				title: "Manual triage required — not approval ready",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "m-0 mt-1 list-disc space-y-0.5 pl-4",
					children: item.audit.filter((event) => event.action === "Status set to Manual Triage").map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: event.detail }, event.id))
				})
			}) : null,
			item.duplicateOf ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Callout, {
				tone: "info",
				title: "Linked as a duplicate",
				children: [
					"This case is linked to",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mono",
						children: item.duplicateOf
					}),
					"."
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WasteReviewPanel, {
				item,
				onRefresh: () => {
					getComplaint(caseId).then(setItem).catch(console.error);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OriginalComplaint, { item }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClassificationPanel, {
				item,
				canOverride: can(session, "case.override")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EvidencePanel, { item }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DraftPanel, {
				item,
				canEdit: can(session, "case.edit_draft"),
				canApprove: can(session, "case.approve") && draftReady
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionsPanel, { item }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommentsPanel, {
				item,
				canComment: can(session, "case.comment")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuditPanel, { item })
		]
	});
}
function OriginalComplaint({ item }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SectionCard, {
		title: "Original complaint",
		meta: "Stored unchanged (SRS 7.3)",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "original-text m-0",
				children: item.text
			}),
			item.attachments.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "m-0 mt-4 list-none space-y-1 p-0 text-xs muted",
				children: item.attachments.map((file) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "min-w-0 truncate",
						children: file.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "subtle shrink-0",
						children: formatBytes(file.size)
					})]
				}, file.name))
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "kicker mt-5",
				children: "Extracted entities"
			}),
			item.entities.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm muted",
				children: "No configured entity was found in this complaint."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "table-scroll mt-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "table",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							scope: "col",
							children: "Type"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							scope: "col",
							children: "Value"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							scope: "col",
							children: "Normalized"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							scope: "col",
							children: "Confidence"
						})
					] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: item.entities.map((entity) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "whitespace-nowrap font-bold",
							children: entity.type
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: entity.value }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "mono",
							children: entity.normalized
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: percent(entity.confidence) })
					] }, `${entity.type}-${entity.span[0]}`)) })]
				})
			})
		]
	});
}
function ClassificationPanel({ item, canOverride }) {
	const classification = item.classification;
	const [open, setOpen] = (0, import_react.useState)(false);
	const [intent, setIntent] = (0, import_react.useState)(classification?.intent ?? "");
	const [department, setDepartment] = (0, import_react.useState)(classification?.department ?? "");
	const [reason, setReason] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	if (!classification) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
		title: "AI classification",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "m-0 text-sm muted",
			children: "Analysis has not finished for this case yet."
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SectionCard, {
		title: "AI classification and routing",
		meta: `Model ${classification.modelVersion} · taxonomy ${classification.taxonomyVersion}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "kicker",
					children: "Predicted intent"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "m-0 text-sm font-bold",
					children: classification.intent
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "kicker",
					children: "Recommended department"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "m-0 text-sm font-bold",
					children: classification.department
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfidenceMeter, {
					value: classification.confidence,
					threshold: CONFIG.confidenceThreshold
				})
			}),
			classification.ruleApplied ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-xs muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Routing rule applied:" }),
					" ",
					classification.ruleApplied
				]
			}) : null,
			classification.overriddenBy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Callout, {
					tone: "info",
					title: "Overridden by a human",
					children: [classification.overriddenBy, " replaced the predicted intent or department. The original prediction is kept in the audit trail."]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "kicker mt-5",
				children: "Alternative predictions"
			}),
			classification.alternatives.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm muted",
				children: "No alternative scored above zero."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "m-0 mt-2 list-none space-y-1 p-0 text-sm",
				children: classification.alternatives.map((alternative) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex flex-wrap justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						alternative.intent,
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "subtle",
							children: ["→ ", alternative.department]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "muted",
						children: percent(alternative.confidence)
					})]
				}, alternative.intent))
			}),
			canOverride ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 border-t border-(--line) pt-4",
				children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "grid gap-3",
					onSubmit: (event) => {
						event.preventDefault();
						if (reason.trim().length < 4) {
							setError("A reason is mandatory for an override (BR-02).");
							return;
						}
						overrideClassification(item.id, {
							intent,
							department,
							reason: reason.trim()
						});
						setOpen(false);
						setReason("");
						setError("");
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "label",
								htmlFor: "ov-intent",
								children: "Intent"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "ov-intent",
								className: "input",
								value: intent,
								onChange: (event) => setIntent(event.target.value)
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "label",
								htmlFor: "ov-dept",
								children: "Department"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								id: "ov-dept",
								className: "select",
								value: department,
								onChange: (event) => setDepartment(event.target.value),
								children: DEPARTMENTS.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: option,
									children: option
								}, option))
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "label",
								htmlFor: "ov-reason",
								children: ["Reason", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "req",
									children: "*"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "ov-reason",
								className: "input",
								value: reason,
								"aria-invalid": Boolean(error),
								onChange: (event) => setReason(event.target.value)
							}),
							error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "field-error",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									"aria-hidden": "true",
									children: "!"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: error })]
							}) : null
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-2 sm:flex-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								className: "btn btn-primary btn-sm",
								children: "Save override"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-quiet btn-sm",
								onClick: () => setOpen(false),
								children: "Cancel"
							})]
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-sm",
					onClick: () => setOpen(true),
					children: "Override intent or department"
				})
			}) : null
		]
	});
}
function EvidencePanel({ item }) {
	const citedIds = item.aiDraft?.evidenceIds ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SectionCard, {
		title: "Retrieved policy evidence",
		meta: `Hybrid retrieval · dense ${CONFIG.denseWeight} / BM25 ${CONFIG.keywordWeight} · ${EMBEDDING_MODEL}`,
		children: [item.evidence.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Callout, {
			tone: "warn",
			title: "No evidence cleared the threshold",
			children: [
				"Nothing in the active policy set scored at or above",
				" ",
				CONFIG.evidenceThreshold,
				" for this complaint, so no grounded draft can be produced (FR-16, BR-03)."
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "m-0 grid list-none gap-3 p-0",
			children: item.evidence.map((evidence, index) => {
				const cited = citedIds.indexOf(evidence.chunkId);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "evidence",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "m-0 text-sm font-bold",
									children: evidence.documentTitle
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "m-0 text-xs muted",
									children: [
										evidence.section,
										" · page ",
										evidence.page,
										" · version",
										" ",
										evidence.version,
										" · effective",
										" ",
										formatDate(evidence.effectiveDate)
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex shrink-0 flex-wrap gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "pill",
									children: ["rank ", index + 1]
								}), cited >= 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "pill",
									"data-tone": "ok",
									children: [
										"cited [",
										cited + 1,
										"]"
									]
								}) : null]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "evidence-quote",
							children: evidence.snippet
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs subtle",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["dense ", evidence.denseScore.toFixed(3)] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["bm25 ", evidence.keywordScore.toFixed(3)] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-bold",
									children: ["hybrid ", evidence.hybridScore.toFixed(3)]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mono",
									children: evidence.chunkId
								})
							]
						})
					]
				}, evidence.chunkId);
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "hint",
			children: "Only chunks belonging to an active policy version and the routed department are searched (FR-13, FR-27)."
		})]
	});
}
function DraftPanel({ item, canEdit, canApprove }) {
	const draft = item.aiDraft;
	const [text, setText] = (0, import_react.useState)(activeDraft(item));
	const [nextStatus, setNextStatus] = (0, import_react.useState)("Assigned to Department");
	(0, import_react.useEffect)(() => {
		setText(activeDraft(item));
	}, [
		item.id,
		item.aiDraft?.createdAt,
		item.editedDraft
	]);
	if (!draft) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
		title: "AI draft response",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "m-0 text-sm muted",
			children: "No draft has been generated yet."
		})
	});
	const abstained = draft.grounding === "Insufficient Evidence";
	const untouched = item.editedDraft === null;
	const approvalBlocked = abstained && untouched;
	const dirty = text !== activeDraft(item);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
		title: "Draft response",
		meta: `${draft.generationModel} · generated ${formatDateTime(draft.createdAt)}`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, {
					tone: abstained ? "warn" : "ok",
					title: `Grounding check: ${draft.grounding}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "m-0 mt-1 list-disc space-y-0.5 pl-4",
						children: draft.groundingNotes.map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: note }, note))
					})
				}),
				item.resolution ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Callout, {
					tone: "ok",
					title: "Already approved and sent",
					children: [
						"Approved by ",
						item.resolution.approver,
						" on",
						" ",
						formatDateTime(item.resolution.sentAt),
						"."
					]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
					className: "card card-pad",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
						className: "cursor-pointer text-sm font-bold",
						children: "Original AI draft (immutable)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "draft-box mt-3",
						children: draft.text
					})]
				}),
				canEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "label",
						htmlFor: "draft-editor",
						children: ["Working copy ", item.editedDraft !== null ? "(edited)" : ""]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						id: "draft-editor",
						className: "textarea min-h-64",
						value: text,
						onChange: (event) => setText(event.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "hint",
						children: "Editing never changes the stored AI original; the edit is saved as a new version and recorded in the audit trail (FR-19)."
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "draft-box",
					children: activeDraft(item)
				}),
				approvalBlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, {
					tone: "warn",
					title: "Approval blocked",
					children: "This draft abstained because no active policy evidence supports a reply. Write a response in the working copy and save it, or reassign the case, before approving."
				}) : null,
				canEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2 sm:flex-row sm:items-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-sm",
						disabled: !dirty,
						onClick: () => saveDraftEdit(item.id, text),
						children: "Save edit"
					}), dirty ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-quiet btn-sm",
						onClick: () => setText(activeDraft(item)),
						children: "Discard changes"
					}) : null]
				}) : null,
				canApprove ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "grid gap-2 border-t border-(--line) pt-4 sm:grid-cols-[1fr_auto] sm:items-end",
					onSubmit: async (event) => {
						event.preventDefault();
						try {
							await approveComplaint(item.id, {
								admin_id: 2,
								final_response: text
							});
							window.location.reload();
						} catch (error) {
							console.error("Failed to approve complaint:", error);
						}
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "label",
							htmlFor: "next-status",
							children: "Status after sending"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							id: "next-status",
							className: "select",
							value: nextStatus,
							onChange: (event) => setNextStatus(event.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "Assigned to Department",
								children: "Assigned to Department"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "Resolved",
								children: "Resolved"
							})]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "btn btn-primary",
							disabled: approvalBlocked || Boolean(item.resolution),
							children: "Approve and send"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "hint sm:col-span-2",
							children: "Your name is recorded as the approver. Nothing leaves the system without this action (FR-20, BR-01, AI-08)."
						})
					]
				}) : null
			]
		})
	});
}
function ActionsPanel({ item }) {
	const { session } = useAppState();
	const [kind, setKind] = (0, import_react.useState)("reassign");
	const [department, setDepartment] = (0, import_react.useState)(DEPARTMENTS[0]);
	const [duplicateOf, setDuplicateOf] = (0, import_react.useState)("");
	const [status, setStatusValue] = (0, import_react.useState)("");
	const [reason, setReason] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [done, setDone] = (0, import_react.useState)("");
	const allowedActions = can(session, "case.reassign") ? [
		"reassign",
		"escalate",
		"reject",
		"duplicate",
		"status"
	] : can(session, "case.status") ? ["escalate", "status"] : [];
	const transitions = ALLOWED_TRANSITIONS[item.status];
	const active = allowedActions.includes(kind) ? kind : allowedActions[0];
	if (allowedActions.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
		title: "Administrator actions",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "m-0 text-sm muted",
			children: "Your role cannot change this case. Sign in as a support administrator to review it."
		})
	});
	function submit(event) {
		event.preventDefault();
		setDone("");
		if (reason.trim().length < 4) {
			setError("A reason is mandatory and is written to the audit log (BR-02).");
			return;
		}
		if (active === "reassign") reassign(item.id, department, reason.trim());
		else if (active === "escalate") escalate(item.id, reason.trim());
		else if (active === "reject") reject(item.id, reason.trim());
		else if (active === "duplicate") {
			if (!/^grv-\d{4}-\d{4}$/i.test(duplicateOf.trim())) {
				setError("Enter the reference of the original case, for example GRV-2026-0431.");
				return;
			}
			markDuplicate(item.id, duplicateOf.trim(), reason.trim());
		} else {
			if (!status) {
				setError("Choose the status to move this case to.");
				return;
			}
			if (!setStatus(item.id, status, reason.trim())) {
				setError("That transition is not permitted from the current status (BR-06).");
				return;
			}
		}
		setError("");
		setReason("");
		setDuplicateOf("");
		setDone("Action applied and recorded in the audit trail.");
	}
	const LABELS = {
		reassign: "Reassign to another department",
		escalate: "Escalate for senior review",
		reject: "Reject as invalid or out of scope",
		duplicate: "Mark as duplicate of another case",
		status: "Change status"
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
		title: "Administrator actions",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "grid gap-3",
			onSubmit: submit,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "label",
					htmlFor: "action-kind",
					children: "Action"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					id: "action-kind",
					className: "select",
					value: active,
					onChange: (event) => {
						setKind(event.target.value);
						setError("");
						setDone("");
					},
					children: allowedActions.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: option,
						children: LABELS[option]
					}, option))
				})] }),
				active === "reassign" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "label",
					htmlFor: "action-dept",
					children: "New department"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					id: "action-dept",
					className: "select",
					value: department,
					onChange: (event) => setDepartment(event.target.value),
					children: DEPARTMENTS.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: option,
						children: option
					}, option))
				})] }) : null,
				active === "duplicate" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "label",
					htmlFor: "action-duplicate",
					children: "Original case reference"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "action-duplicate",
					className: "input mono",
					placeholder: "GRV-2026-0431",
					value: duplicateOf,
					onChange: (event) => setDuplicateOf(event.target.value)
				})] }) : null,
				active === "status" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "label",
						htmlFor: "action-status",
						children: "New status"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						id: "action-status",
						className: "select",
						value: status,
						onChange: (event) => setStatusValue(event.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Select a status…"
						}), transitions.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: option,
							children: option
						}, option))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "hint",
						children: [
							"Only transitions permitted from ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: item.status }),
							" are listed (BR-06)."
						]
					})
				] }) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "label",
						htmlFor: "action-reason",
						children: ["Reason", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "req",
							children: "*"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						id: "action-reason",
						className: "textarea min-h-20",
						value: reason,
						"aria-invalid": Boolean(error),
						onChange: (event) => setReason(event.target.value)
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "field-error",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": "true",
							children: "!"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: error })]
					}) : null
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2 sm:flex-row sm:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: active === "reject" ? "btn btn-danger" : "btn btn-primary",
						children: "Apply action"
					}), done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-bold text-(--ok)",
						role: "status",
						children: done
					}) : null]
				})
			]
		})
	});
}
function CommentsPanel({ item, canComment }) {
	const [text, setText] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SectionCard, {
		title: "Internal comments",
		bodyClassName: "",
		children: [item.comments.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, { children: "No internal comments on this case yet." }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "m-0 list-none divide-rows p-0",
			children: item.comments.map((comment) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "m-0 text-sm",
					children: comment.text
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "m-0 mt-1 text-xs subtle",
					children: [
						comment.author,
						" · ",
						formatDateTime(comment.at)
					]
				})]
			}, comment.id))
		}), canComment ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "border-t border-(--line) p-4",
			onSubmit: (event) => {
				event.preventDefault();
				if (text.trim().length < 2) return;
				addComment(item.id, text.trim());
				setText("");
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "label",
					htmlFor: "comment",
					children: "Add a comment"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					id: "comment",
					className: "textarea min-h-20",
					value: text,
					onChange: (event) => setText(event.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "btn btn-sm mt-2",
					disabled: text.trim().length < 2,
					children: "Add comment"
				})
			]
		}) : null]
	});
}
function AuditPanel({ item }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
		title: "Audit trail",
		meta: `${item.audit.length} events`,
		bodyClassName: "",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "m-0 list-none divide-rows p-0",
			children: [...item.audit].reverse().map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "px-4 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-baseline justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "m-0 text-sm font-bold",
							children: event.action
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "m-0 text-xs subtle",
							children: formatDateTime(event.at)
						})]
					}),
					event.detail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "m-0 mt-1 text-xs muted",
						children: event.detail
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "m-0 mt-1 text-xs subtle",
						children: [
							event.actor,
							" · ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mono",
								children: event.requestId
							})
						]
					})
				]
			}, event.id))
		})
	});
}
function WasteReviewPanel({ item, onRefresh }) {
	const [cleaners, setCleaners] = (0, import_react.useState)([]);
	const [decision, setDecision] = (0, import_react.useState)("approve_cleanup");
	const [cleanerId, setCleanerId] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [success, setSuccess] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		listCleaners().then((data) => {
			setCleaners(data);
			if (data.length > 0) setCleanerId(String(data[0].id));
		}).catch((err) => console.error("Failed to list cleaners:", err));
	}, []);
	const handleSubmit = async (e) => {
		e.preventDefault();
		setError(null);
		setSuccess(null);
		if (decision === "approve_cleanup" && !cleanerId) {
			setError("Please select a cleaner for assignment.");
			return;
		}
		setLoading(true);
		try {
			await reviewWasteComplaint(item.id, {
				decision,
				cleaner_id: decision === "approve_cleanup" ? Number(cleanerId) : null,
				notes: notes.trim() || null
			});
			setSuccess(`Waste complaint review submitted! Status set to ${decision === "approve_cleanup" ? "assigned" : "rejected"}.`);
			onRefresh();
		} catch (err) {
			setError(err?.message || "Failed to submit review.");
		} finally {
			setLoading(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SectionCard, {
		title: "Waste Complaint Review & Assignment",
		meta: "AI Waste Classification & Dispatch",
		children: [
			success ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, {
				tone: "ok",
				title: "Review Complete",
				children: success
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, {
				tone: "danger",
				title: "Review Error",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "kicker",
						children: "AI Waste Analysis"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-2 grid grid-cols-2 gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-(--surface-2) p-2.5 rounded",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "kicker",
								children: "Waste Type"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "m-0 font-bold capitalize",
								children: item.wasteType ?? item.classification?.intent ?? "General Waste"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-(--surface-2) p-2.5 rounded",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "kicker",
								children: "Severity"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "m-0 font-bold capitalize",
								children: item.severity ?? "Normal"
							})]
						})]
					}),
					item.aiReasoning ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 text-xs muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "kicker",
							children: "AI Reasoning"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "m-0 italic",
							children: item.aiReasoning
						})]
					}) : null,
					item.imagePath ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "kicker",
							children: "Submitted Image (Before)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 max-w-xs rounded overflow-hidden border border-(--line)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: getBackendImageUrl(item.imagePath) ?? void 0,
								alt: "Before cleanup waste complaint",
								className: "w-full h-auto max-h-48 object-cover"
							})
						})]
					}) : null
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-t border-(--line) pt-4 md:border-t-0 md:border-l md:pl-4 md:pt-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "kicker",
						children: "Admin Decision"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mt-2 grid gap-3",
						onSubmit: handleSubmit,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "label",
								children: "Review Decision"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-4 mt-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-center gap-1.5 cursor-pointer text-sm font-semibold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "radio",
										name: "decision",
										value: "approve_cleanup",
										checked: decision === "approve_cleanup",
										onChange: () => setDecision("approve_cleanup")
									}), "Approve & Assign Cleanup"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-center gap-1.5 cursor-pointer text-sm font-semibold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "radio",
										name: "decision",
										value: "reject",
										checked: decision === "reject",
										onChange: () => setDecision("reject")
									}), "Reject Complaint"]
								})]
							})] }),
							decision === "approve_cleanup" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "label",
								htmlFor: "cleaner-select",
								children: "Assign Cleaner"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								id: "cleaner-select",
								className: "select",
								value: cleanerId,
								onChange: (e) => setCleanerId(e.target.value),
								children: cleaners.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "No available cleaners found"
								}) : cleaners.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: c.id,
									children: [
										c.name,
										" (",
										c.email,
										")"
									]
								}, c.id))
							})] }) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "label",
								htmlFor: "review-notes",
								children: "Notes (Optional)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "review-notes",
								className: "input",
								value: notes,
								placeholder: "Enter assignment notes or rejection reason...",
								onChange: (e) => setNotes(e.target.value)
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								className: "btn btn-primary mt-2",
								disabled: loading,
								children: loading ? "Submitting..." : decision === "approve_cleanup" ? "Approve & Assign Cleaner" : "Reject Complaint"
							})
						]
					})]
				})]
			})
		]
	});
}
//#endregion
export { CaseDetailPage as component };
