import { r as __toESM } from "../_runtime.mjs";
import { R as require_react, _ as Link, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as getBackendImageUrl, D as listCleanupTasks, N as verifyCleanupTask } from "./router-DxxzZ2Qy.mjs";
import { c as StatusPill, t as Callout } from "./ui-DYNAo6oe.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.verification-CJYkY4t7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminVerificationPage() {
	const [tasks, setTasks] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [error, setError] = (0, import_react.useState)(null);
	const [actionMessage, setActionMessage] = (0, import_react.useState)(null);
	const [submittingTaskId, setSubmittingTaskId] = (0, import_react.useState)(null);
	const [notesMap, setNotesMap] = (0, import_react.useState)({});
	const fetchVerificationTasks = async () => {
		setLoading(true);
		setError(null);
		try {
			const data = await listCleanupTasks();
			setTasks(data);
		} catch (err) {
			setError(err?.message || "Failed to load verification tasks. Ensure you are signed in as an admin.");
		} finally {
			setLoading(false);
		}
	};
	(0, import_react.useEffect)(() => {
		fetchVerificationTasks();
	}, []);
	const handleVerify = async (taskId, decision) => {
		setSubmittingTaskId(taskId);
		setError(null);
		setActionMessage(null);
		const notes = notesMap[taskId]?.trim() || null;
		try {
			await verifyCleanupTask(taskId, {
				decision,
				notes
			});
			setActionMessage(`Verification decision '${decision}' recorded for Task #${taskId}. Complaint updated.`);
			await fetchVerificationTasks();
		} catch (err) {
			setError(err?.message || "Failed to record verification decision.");
		} finally {
			setSubmittingTaskId(null);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-between items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-bold",
					children: "Cleanup Verification Queue"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm muted m-0",
					children: "Inspect uploaded cleanup proof photos against initial reports and verify work completion."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-sm btn-quiet",
					onClick: fetchVerificationTasks,
					children: "Refresh Queue"
				})]
			}),
			actionMessage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, {
				tone: "ok",
				title: "Decision Recorded",
				children: actionMessage
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Callout, {
				tone: "danger",
				title: "Error",
				children: [
					error,
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/login",
						className: "underline font-semibold",
						children: "Sign in as Admin"
					})
				]
			}) : null,
			loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "card card-pad text-center muted",
				children: "Loading verification tasks..."
			}) : tasks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "card card-pad text-center muted",
				children: "No cleanup tasks currently awaiting verification."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4",
				children: tasks.map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card card-pad grid gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-start justify-between gap-2 border-b border-(--line) pb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "kicker",
								children: [
									"Task #",
									task.id,
									" · Ref: ",
									task.tracking_id
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "text-base font-extrabold mt-0.5",
								children: [
									"Complaint #",
									task.complaint_id,
									" — Cleaner: ",
									task.cleaner_name,
									" (",
									task.cleaner_email,
									")"
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "pill",
									children: ["Task: ", task.status]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: task.complaint_status })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 md:grid-cols-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "kicker",
									children: "Complaint Text"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "m-0 text-(--fg) font-medium",
									children: task.complaint_text
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 grid grid-cols-2 gap-2 text-xs bg-(--surface-2) p-2.5 rounded",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "kicker",
										children: "Waste Type"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "m-0 font-bold capitalize",
										children: task.waste_type ?? "N/A"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "kicker",
										children: "Severity"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "m-0 font-bold capitalize",
										children: task.severity ?? "Normal"
									})] })]
								}),
								task.verification_status ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 text-xs bg-(--surface-2) p-2.5 rounded space-y-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "kicker",
											children: "AI Verification Assessment"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "m-0",
											children: [
												"Status: ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: task.verification_status }),
												" | Confidence:",
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [((task.verification_confidence ?? 0) * 100).toFixed(0), "%"] })
											]
										}),
										task.verification_reason ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "m-0 italic subtle",
											children: task.verification_reason
										}) : null
									]
								}) : null
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "kicker block text-xs",
									children: "Before Image"
								}), task.image_path ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-1 rounded overflow-hidden border border-(--line)",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: getBackendImageUrl(task.image_path) ?? void 0,
										alt: "Before cleanup",
										className: "w-full h-auto max-h-40 object-cover"
									})
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs muted italic mt-2",
									children: "No before image"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "kicker block text-xs",
									children: "Proof Image (After)"
								}), task.proof_image_path ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-1 rounded overflow-hidden border border-(--line)",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: getBackendImageUrl(task.proof_image_path) ?? void 0,
										alt: "Cleanup proof after",
										className: "w-full h-auto max-h-40 object-cover"
									})
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs muted italic mt-2",
									children: "No proof uploaded"
								})] })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pt-3 border-t border-(--line) flex flex-wrap items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex-1 min-w-[240px]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									className: "input text-xs",
									placeholder: "Verification notes / feedback (optional)...",
									value: notesMap[task.id] ?? "",
									onChange: (e) => setNotesMap((prev) => ({
										...prev,
										[task.id]: e.target.value
									}))
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-primary btn-sm",
									disabled: submittingTaskId === task.id,
									onClick: () => handleVerify(task.id, "approve"),
									children: "Approve Cleanup"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-quiet btn-sm text-(--warn)",
									disabled: submittingTaskId === task.id,
									onClick: () => handleVerify(task.id, "reject"),
									children: "Reject (Require Rework)"
								})]
							})]
						})
					]
				}, task.id))
			})
		]
	});
}
//#endregion
export { AdminVerificationPage as component };
