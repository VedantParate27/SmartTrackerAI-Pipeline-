//#region node_modules/.nitro/vite/services/ssr/assets/taxonomy-tJaYsAgr.js
/** TBD-01 placeholder taxonomy. Configurable, not hard-coded in components. */
var TAXONOMY_VERSION = "tax-2026.02";
var CLASSIFIER_VERSION = "intent-clf-0.4.1";
var GENERATION_MODEL = "grounded-draft-0.3.0";
var EMBEDDING_MODEL = "embed-mini-384";
var DEPARTMENTS = [
	"Finance & Payroll",
	"Human Resources",
	"IT Support",
	"Facilities & Maintenance",
	"Billing & Refunds",
	"Public Records"
];
var PRIORITIES = [
	"Low",
	"Medium",
	"High"
];
var STATUSES = [
	"Submitted",
	"AI Analysis",
	"Pending Review",
	"Manual Triage",
	"Assigned to Department",
	"In Progress",
	"Escalated",
	"Resolved",
	"Closed",
	"Rejected",
	"Duplicate"
];
/** AI-02: thresholds are configurable and must be validated on a test set. */
var CONFIG = {
	/** FR-10: below this the case goes to Manual Triage. */
	confidenceThreshold: .62,
	/** FR-16: below this there is no usable evidence, so the draft abstains. */
	evidenceThreshold: .18,
	/** Top-k for both retrievers before the merge step. */
	topK: 5,
	/** Weights for the hybrid merge (dense vs BM25). */
	denseWeight: .6,
	keywordWeight: .4,
	maxAttachments: 3,
	maxAttachmentBytes: 5242880,
	allowedAttachmentTypes: [
		"application/pdf",
		"text/plain",
		"image/png",
		"image/jpeg"
	]
};
var STATUS_MEANING = {
	Submitted: "Case is stored and waiting for processing.",
	"AI Analysis": "Classification, extraction, retrieval and draft generation are running.",
	"Pending Review": "AI results are available for a human administrator.",
	"Manual Triage": "Confidence or evidence was insufficient, so a human must triage this case.",
	"Assigned to Department": "Case has an authorised departmental owner.",
	"In Progress": "Department is actively handling the grievance.",
	Verification: "Cleanup proof is submitted and awaiting verification.",
	Escalated: "Senior or specialist review is required due to risk, uncertainty or delay.",
	Resolved: "A resolution has been recorded and communicated.",
	Closed: "No further action is expected; the case remains available for audit.",
	Rejected: "Case is invalid, spam or out of scope.",
	Duplicate: "Case is linked to an existing case."
};
var STATUS_TONE = {
	Submitted: "neutral",
	"AI Analysis": "info",
	"Pending Review": "info",
	"Manual Triage": "warn",
	"Assigned to Department": "info",
	"In Progress": "info",
	Verification: "info",
	Escalated: "warn",
	Resolved: "ok",
	Closed: "neutral",
	Rejected: "danger",
	Duplicate: "neutral"
};
/** BR-06: every status transition must be allowed by the workflow. */
var ALLOWED_TRANSITIONS = {
	Submitted: ["AI Analysis", "Rejected"],
	"AI Analysis": ["Pending Review", "Manual Triage"],
	"Pending Review": [
		"Assigned to Department",
		"Escalated",
		"Resolved",
		"Rejected",
		"Duplicate"
	],
	"Manual Triage": [
		"Assigned to Department",
		"Pending Review",
		"Escalated",
		"Rejected",
		"Duplicate"
	],
	"Assigned to Department": [
		"In Progress",
		"Escalated",
		"Resolved"
	],
	"In Progress": [
		"Verification",
		"Escalated",
		"Resolved"
	],
	Verification: [
		"Resolved",
		"In Progress",
		"Escalated"
	],
	Escalated: ["In Progress", "Resolved"],
	Resolved: ["Closed"],
	Closed: [],
	Rejected: ["Closed"],
	Duplicate: ["Closed"]
};
function canTransition(from, to) {
	return ALLOWED_TRANSITIONS[from].includes(to);
}
/** NFR-05 / BR-01: role-based access control. */
var PERMISSIONS = {
	Requester: [],
	"Support Administrator": [
		"case.read.all",
		"case.edit_draft",
		"case.approve",
		"case.reassign",
		"case.override",
		"case.comment"
	],
	"Department Officer": [
		"case.read.department",
		"case.comment",
		"case.status"
	],
	"Knowledge Manager": ["policy.manage"],
	"System Administrator": [
		"case.read.all",
		"policy.manage",
		"config.manage"
	]
};
function can(session, permission) {
	return PERMISSIONS[session.role].includes(permission);
}
var SESSIONS = [
	{
		role: "Support Administrator",
		name: "A. Patil",
		departments: null
	},
	{
		role: "Department Officer",
		name: "K. Lanke",
		departments: ["Finance & Payroll"]
	},
	{
		role: "Knowledge Manager",
		name: "V. Parate",
		departments: null
	}
];
//#endregion
export { EMBEDDING_MODEL as a, SESSIONS as c, STATUS_TONE as d, TAXONOMY_VERSION as f, DEPARTMENTS as i, STATUSES as l, canTransition as m, CLASSIFIER_VERSION as n, GENERATION_MODEL as o, can as p, CONFIG as r, PRIORITIES as s, ALLOWED_TRANSITIONS as t, STATUS_MEANING as u };
