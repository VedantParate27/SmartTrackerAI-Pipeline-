import { c as SESSIONS } from "./taxonomy-tJaYsAgr.mjs";
import { _ as Link, p as Outlet, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as setSession, m as resetStore, y as useAppState } from "./router-DxxzZ2Qy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-BPAkCfe1.js
var import_jsx_runtime = require_jsx_runtime();
function AdminLayout() {
	const { session } = useAppState();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "main",
		className: "wrap page",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: "Administration"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-2xl font-extrabold sm:text-3xl",
					children: "Review workspace"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex w-full items-end gap-2 sm:w-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1 sm:flex-none",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "kicker block",
							htmlFor: "session",
							children: "Signed in as"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							id: "session",
							className: "select mt-1 text-sm",
							value: session.role,
							onChange: (event) => {
								const next = SESSIONS.find((item) => item.role === event.target.value);
								if (next) setSession(next);
							},
							children: SESSIONS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: item.role,
								children: [
									item.name,
									" — ",
									item.role
								]
							}, item.role))
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-sm shrink-0",
						onClick: () => {
							if (window.confirm("Reset the demo back to the seeded cases and policies? Cases you submitted in this browser will be removed.")) resetStore();
						},
						children: "Reset demo data"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				"aria-label": "Administration sections",
				className: "mt-4 flex gap-1 overflow-x-auto pb-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/admin",
						activeOptions: { exact: true },
						className: "nav-link shrink-0",
						activeProps: { className: "nav-link is-active shrink-0" },
						children: "Case queue"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/admin/verification",
						className: "nav-link shrink-0",
						activeProps: { className: "nav-link is-active shrink-0" },
						children: "Cleanup verification queue"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/admin/knowledge",
						className: "nav-link shrink-0",
						activeProps: { className: "nav-link is-active shrink-0" },
						children: "Policy knowledge base"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
			})
		]
	});
}
//#endregion
export { AdminLayout as component };
