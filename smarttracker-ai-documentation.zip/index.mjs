globalThis.__nitro_main__ = import.meta.url;
import { a as toEventHandler, c as NodeResponse, i as defineLazyEventHandler, l as serve, n as HTTPError, r as defineHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/assets/admin.cases._caseId-B8tche7S.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5db2-WrffnSXjNLjnFnFPgfi6A4R/O0M\"",
		"mtime": "2026-10-05T17:43:53.561Z",
		"size": 23986,
		"path": "../public/assets/admin.cases._caseId-B8tche7S.js"
	},
	"/assets/admin-yvWRI4_M.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7b3-UWe0k/abI5m1Rj/luXoCMpjEPck\"",
		"mtime": "2026-10-05T17:43:53.558Z",
		"size": 1971,
		"path": "../public/assets/admin-yvWRI4_M.js"
	},
	"/assets/admin.index-CLaX-KXY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ccf-4QO2y1KKtHTcZinKRUsc06T8jac\"",
		"mtime": "2026-10-05T17:43:53.565Z",
		"size": 7375,
		"path": "../public/assets/admin.index-CLaX-KXY.js"
	},
	"/assets/admin.knowledge-BziXiG96.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"212d-poVpCaTdKPQlJgctWIGbvU4cARg\"",
		"mtime": "2026-10-05T17:43:53.568Z",
		"size": 8493,
		"path": "../public/assets/admin.knowledge-BziXiG96.js"
	},
	"/assets/admin.verification-CJd0f8gA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"154b-qwHkqC8UEAULCMSD6ObJBdRuWoM\"",
		"mtime": "2026-10-05T17:43:53.568Z",
		"size": 5451,
		"path": "../public/assets/admin.verification-CJd0f8gA.js"
	},
	"/assets/guide-c0ZewEr1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1530-19lf37UipfEUmKvNhmSe2oEA804\"",
		"mtime": "2026-10-05T17:43:53.572Z",
		"size": 5424,
		"path": "../public/assets/guide-c0ZewEr1.js"
	},
	"/assets/cleaner-M_D46tNc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"16fb-EwokeKypsC5eMcqGTQipqe8puw8\"",
		"mtime": "2026-10-05T17:43:53.570Z",
		"size": 5883,
		"path": "../public/assets/cleaner-M_D46tNc.js"
	},
	"/assets/link-oqsraY1L.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6252-cB5bAaT31lzTgDZZoU0FLCYXaTc\"",
		"mtime": "2026-10-05T17:43:53.577Z",
		"size": 25170,
		"path": "../public/assets/link-oqsraY1L.js"
	},
	"/assets/Match-DqwsLDrL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1142-K6JVwYYNdN4fiF2H3evCOnc0tcY\"",
		"mtime": "2026-10-05T17:43:53.556Z",
		"size": 4418,
		"path": "../public/assets/Match-DqwsLDrL.js"
	},
	"/assets/login-ANBvaU0N.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9c5-BbZ8pEWuztULIDaSqinaXDw6o+M\"",
		"mtime": "2026-10-05T17:43:53.579Z",
		"size": 2501,
		"path": "../public/assets/login-ANBvaU0N.js"
	},
	"/assets/routes-BGtZijZ5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fcb-5nvIr31ZwaFPdZ8viiWiWuvcq9E\"",
		"mtime": "2026-10-05T17:43:53.583Z",
		"size": 4043,
		"path": "../public/assets/routes-BGtZijZ5.js"
	},
	"/assets/submit-BjdttF_b.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2759-OHjVlpyUE1hiy78qdN+mrJD+fNY\"",
		"mtime": "2026-10-05T17:43:53.584Z",
		"size": 10073,
		"path": "../public/assets/submit-BjdttF_b.js"
	},
	"/assets/styles-DKjk-iiK.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"6a4d-v3hA3qYqQfV2QBp5gAfm8vAL5X4\"",
		"mtime": "2026-10-05T17:43:53.593Z",
		"size": 27213,
		"path": "../public/assets/styles-DKjk-iiK.css"
	},
	"/assets/ui-CwMINNqo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ecc-D0KEQJDLaRIlrtpv6yJLEqcjRIY\"",
		"mtime": "2026-10-05T17:43:53.589Z",
		"size": 3788,
		"path": "../public/assets/ui-CwMINNqo.js"
	},
	"/assets/taxonomy-DEneqMO4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2c7e-07Y9EiaS4muA8OOM3+AE3AKgMoo\"",
		"mtime": "2026-10-05T17:43:53.586Z",
		"size": 11390,
		"path": "../public/assets/taxonomy-DEneqMO4.js"
	},
	"/assets/index-B03xIXTO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4d3ad-Bg1I5ht4T979ngqGMsq5wVXQzR4\"",
		"mtime": "2026-10-05T17:43:53.552Z",
		"size": 316333,
		"path": "../public/assets/index-B03xIXTO.js"
	},
	"/assets/track-Fp8frTb-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"135f-zhIOYznR4zo7NycLuFyYlhrzgYo\"",
		"mtime": "2026-10-05T17:43:53.588Z",
		"size": 4959,
		"path": "../public/assets/track-Fp8frTb-.js"
	},
	"/assets/matchContext-Dg3ft267.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9f-t2fs7QZXEjjutJE5vau+e127+y8\"",
		"mtime": "2026-10-05T17:43:53.581Z",
		"size": 159,
		"path": "../public/assets/matchContext-Dg3ft267.js"
	},
	"/assets/useRouter-6z2K6iyO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"94-XwWnWAyHMCfaWTgSP4Emps3EwJo\"",
		"mtime": "2026-10-05T17:43:53.589Z",
		"size": 148,
		"path": "../public/assets/useRouter-6z2K6iyO.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_sFlQ33 = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_sFlQ33
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
