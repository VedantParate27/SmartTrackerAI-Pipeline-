//#region node_modules/.nitro/vite/services/ssr/assets/seed-CgRMZeL5.js
/**
* Seed content for the demo. Every timestamp here is a fixed literal so the
* server render and the client hydration produce identical markup.
*/
var POLICY_DOCUMENTS = [
	{
		id: "POL-PAY-031",
		title: "Payroll Deduction & Correction Policy",
		owner: "Finance Controller",
		department: "Finance & Payroll",
		policyType: "Policy",
		jurisdiction: "Organisation-wide",
		version: "3.1",
		effectiveDate: "2026-01-01",
		status: "Active",
		pages: 12,
		lastUpdated: "2026-01-04",
		supersedes: "POL-PAY-028",
		ingestion: {
			chunks: 3,
			unreadablePages: [],
			warnings: []
		}
	},
	{
		id: "POL-PAY-028",
		title: "Payroll Deduction & Correction Policy",
		owner: "Finance Controller",
		department: "Finance & Payroll",
		policyType: "Policy",
		jurisdiction: "Organisation-wide",
		version: "2.8",
		effectiveDate: "2024-04-01",
		status: "Retired",
		pages: 10,
		lastUpdated: "2026-01-04",
		supersedes: null,
		ingestion: {
			chunks: 3,
			unreadablePages: [],
			warnings: []
		}
	},
	{
		id: "SOP-REF-024",
		title: "Refund & Chargeback SOP",
		owner: "Billing Operations Lead",
		department: "Billing & Refunds",
		policyType: "SOP",
		jurisdiction: "Organisation-wide",
		version: "2.4",
		effectiveDate: "2025-11-15",
		status: "Active",
		pages: 8,
		lastUpdated: "2025-11-18",
		supersedes: null,
		ingestion: {
			chunks: 3,
			unreadablePages: [],
			warnings: []
		}
	},
	{
		id: "SOP-REF-025",
		title: "Refund & Chargeback SOP",
		owner: "Billing Operations Lead",
		department: "Billing & Refunds",
		policyType: "SOP",
		jurisdiction: "Organisation-wide",
		version: "2.5",
		effectiveDate: "2026-03-01",
		status: "Pending Approval",
		pages: 9,
		lastUpdated: "2026-02-10",
		supersedes: "SOP-REF-024",
		ingestion: {
			chunks: 3,
			unreadablePages: [7],
			warnings: ["Page 7 produced no extractable text (scanned image)."]
		}
	},
	{
		id: "SOP-ITS-040",
		title: "IT Service Continuity & Account Access SOP",
		owner: "IT Service Manager",
		department: "IT Support",
		policyType: "SOP",
		jurisdiction: "Organisation-wide",
		version: "4.0",
		effectiveDate: "2025-09-01",
		status: "Active",
		pages: 15,
		lastUpdated: "2025-09-03",
		supersedes: null,
		ingestion: {
			chunks: 3,
			unreadablePages: [],
			warnings: []
		}
	},
	{
		id: "POL-HRG-020",
		title: "Workplace Grievance Redressal Policy",
		owner: "Head of Human Resources",
		department: "Human Resources",
		policyType: "Policy",
		jurisdiction: "Organisation-wide",
		version: "2.0",
		effectiveDate: "2025-07-01",
		status: "Active",
		pages: 11,
		lastUpdated: "2025-07-05",
		supersedes: null,
		ingestion: {
			chunks: 3,
			unreadablePages: [],
			warnings: []
		}
	},
	{
		id: "SOP-FAC-015",
		title: "Facility Maintenance Service Levels",
		owner: "Facilities Manager",
		department: "Facilities & Maintenance",
		policyType: "SOP",
		jurisdiction: "Campus / Site",
		version: "1.5",
		effectiveDate: "2025-06-01",
		status: "Active",
		pages: 6,
		lastUpdated: "2025-06-02",
		supersedes: null,
		ingestion: {
			chunks: 2,
			unreadablePages: [],
			warnings: []
		}
	},
	{
		id: "SOP-REC-030",
		title: "Public Records Access & Certified Copies SOP",
		owner: "Records Officer",
		department: "Public Records",
		policyType: "SOP",
		jurisdiction: "State",
		version: "3.0",
		effectiveDate: "2025-10-10",
		status: "Active",
		pages: 9,
		lastUpdated: "2025-10-12",
		supersedes: null,
		ingestion: {
			chunks: 2,
			unreadablePages: [],
			warnings: []
		}
	}
];
var POLICY_CHUNKS = [
	{
		id: "POL-PAY-031#c1",
		documentId: "POL-PAY-031",
		page: 4,
		section: "4.2 Unnotified Salary Deduction",
		text: "Any salary deduction that was not communicated to the employee in writing at least seven working days in advance shall be treated as an unnotified deduction. Payroll must publish a deduction advice with the head of deduction, the amount and the applicable month."
	},
	{
		id: "POL-PAY-031#c2",
		documentId: "POL-PAY-031",
		page: 5,
		section: "4.5 Correction and Arrears Release",
		text: "A verified incorrect deduction shall be corrected in the next payroll cycle. Where the deducted amount exceeds one day of gross pay, Finance may release the arrears as an off-cycle payment within ten working days of verification."
	},
	{
		id: "POL-PAY-031#c3",
		documentId: "POL-PAY-031",
		page: 7,
		section: "6.1 Employee Query Handling",
		text: "Payroll shall acknowledge a deduction query within two working days and share the wage register extract and the deduction advice for the disputed month. The employee ID and the payroll month must be quoted in every response."
	},
	{
		id: "SOP-REF-024#c1",
		documentId: "SOP-REF-024",
		page: 2,
		section: "2.1 Refund Timelines",
		text: "An approved refund is credited to the original payment instrument within seven to ten working days. Where the order was cancelled before dispatch, the refund is initiated automatically once the cancellation is confirmed."
	},
	{
		id: "SOP-REF-024#c2",
		documentId: "SOP-REF-024",
		page: 3,
		section: "2.4 Refund Not Received",
		text: "If the refund is not credited after the published timeline, Billing shall obtain the acquirer reference number from the payment gateway and share it with the customer so that the bank can trace the credit. The order ID is mandatory for this trace."
	},
	{
		id: "SOP-REF-024#c3",
		documentId: "SOP-REF-024",
		page: 5,
		section: "3.2 Duplicate and Excess Charges",
		text: "A duplicate charge on the same order shall be reversed in full without deduction. Billing must verify the transaction identifiers of both charges before authorising the reversal."
	},
	{
		id: "SOP-ITS-040#c1",
		documentId: "SOP-ITS-040",
		page: 3,
		section: "3.1 Account Lockout and Password Reset",
		text: "An account is locked after five consecutive failed sign-in attempts and is released automatically after thirty minutes. A user may request an assisted password reset through the service desk after identity verification."
	},
	{
		id: "SOP-ITS-040#c2",
		documentId: "SOP-ITS-040",
		page: 6,
		section: "4.3 Portal Outage and Error Codes",
		text: "Errors in the ERR-5xx range indicate a server-side fault and are handled as a priority incident. The service desk shall record the error code, the affected module and the time of failure, and shall publish a status update every sixty minutes until closure."
	},
	{
		id: "SOP-ITS-040#c3",
		documentId: "SOP-ITS-040",
		page: 9,
		section: "5.2 Incident Response Targets",
		text: "A priority incident receives a first response within one hour and a workaround or resolution plan within four working hours. Users are informed of the reference number and the expected next update."
	},
	{
		id: "POL-HRG-020#c1",
		documentId: "POL-HRG-020",
		page: 2,
		section: "2.2 Filing a Grievance",
		text: "An employee may raise a workplace grievance concerning leave, attendance, shift allocation or supervisory conduct. The grievance is registered confidentially and the employee is protected against retaliation."
	},
	{
		id: "POL-HRG-020#c2",
		documentId: "POL-HRG-020",
		page: 4,
		section: "3.1 Review Timelines",
		text: "The reporting manager and the human resources partner shall complete a first review within five working days. If the grievance concerns the reporting manager, the case is reassigned to the next level of management."
	},
	{
		id: "POL-HRG-020#c3",
		documentId: "POL-HRG-020",
		page: 6,
		section: "4.4 Escalation and Committee Referral",
		text: "A grievance involving harassment, discrimination or safety is escalated to the redressal committee on the same working day and is not closed by the reporting line alone."
	},
	{
		id: "SOP-FAC-015#c1",
		documentId: "SOP-FAC-015",
		page: 2,
		section: "2.1 Response Windows",
		text: "A water leakage, electrical fault or lift failure is treated as an urgent complaint and is attended within four hours of logging. Non-urgent housekeeping requests are attended within two working days."
	},
	{
		id: "SOP-FAC-015#c2",
		documentId: "SOP-FAC-015",
		page: 4,
		section: "3.3 Closure Confirmation",
		text: "A maintenance complaint is closed only after the requester confirms that the work is complete. The technician records the location, the material used and the completion time."
	},
	{
		id: "SOP-REC-030#c1",
		documentId: "SOP-REC-030",
		page: 2,
		section: "2.1 Certified Copy Requests",
		text: "A certified copy of a registered record is issued within fifteen working days of a complete application. The applicant must submit proof of identity and the registration details of the record."
	},
	{
		id: "SOP-REC-030#c2",
		documentId: "SOP-REC-030",
		page: 5,
		section: "3.2 Incomplete Applications",
		text: "An incomplete application is returned with a written list of the missing documents. The applicant may resubmit within thirty days without paying the fee again."
	}
];
/** UC-05 / FR-29 to FR-32. Structured data only; nothing is generated. */
var DOCUMENT_GUIDES = [
	{
		id: "guide-passport",
		title: "Fresh Passport (Ordinary)",
		aliases: [
			"passport",
			"new passport",
			"fresh passport",
			"travel document"
		],
		authority: "Passport Seva / Ministry of External Affairs",
		requiredDocuments: [
			"Proof of present address",
			"Proof of date of birth",
			"Annexure declaration as applicable to the applicant category",
			"Recent passport-size photograph as specified by the appointment centre"
		],
		acceptableProofs: ["Address: Aadhaar, electricity bill, registered rent agreement, bank passbook with photograph", "Date of birth: birth certificate, school leaving certificate, PAN card"],
		steps: [
			"Register on the passport portal and verify the account.",
			"Fill the fresh passport application form and save it.",
			"Pay the fee online and book an appointment slot.",
			"Attend the appointment with the original documents and one photocopy set.",
			"Complete police verification if it is required for your category.",
			"Track the application status with the file reference number."
		],
		fees: "Ordinary 36-page booklet: standard scheme fee; tatkal scheme is charged extra.",
		processingTime: "15 to 30 working days after successful police verification.",
		validity: "10 years for adult applicants.",
		source: "Public Records Access & Certified Copies SOP v3.0, Annexure B",
		lastUpdated: "2025-10-12"
	},
	{
		id: "guide-driving-licence",
		title: "Permanent Driving Licence",
		aliases: [
			"driving licence",
			"driving license",
			"dl",
			"licence",
			"license",
			"learner licence"
		],
		authority: "Regional Transport Office",
		requiredDocuments: [
			"Valid learner licence",
			"Proof of age",
			"Proof of address",
			"Medical fitness declaration for the applicable vehicle class"
		],
		acceptableProofs: ["Age: birth certificate, school certificate, PAN card", "Address: Aadhaar, utility bill, ration card, voter identity card"],
		steps: [
			"Hold the learner licence for the minimum waiting period.",
			"Apply for the permanent licence and select the vehicle class.",
			"Pay the fee and book the driving test slot.",
			"Appear for the driving test at the allotted RTO with your own vehicle if required.",
			"Collect the licence or track dispatch after the test result is recorded."
		],
		fees: "Licence fee plus test fee as notified by the transport authority.",
		processingTime: "7 to 21 working days after a successful driving test.",
		validity: "20 years or until the age of 50, whichever is earlier.",
		source: "Public Records Access & Certified Copies SOP v3.0, Annexure C",
		lastUpdated: "2025-10-12"
	},
	{
		id: "guide-birth-certificate",
		title: "Birth Certificate (Certified Copy)",
		aliases: [
			"birth certificate",
			"birth record",
			"date of birth certificate"
		],
		authority: "Municipal Registrar of Births and Deaths",
		requiredDocuments: [
			"Application form for a certified copy",
			"Hospital record or registration number of the birth",
			"Proof of identity of the applicant",
			"Proof of relationship if the applicant is not the record holder"
		],
		acceptableProofs: ["Identity: Aadhaar, passport, voter identity card", "Relationship: parent name on the record, or an affidavit"],
		steps: [
			"Search the registration details using the date and place of birth.",
			"Submit the application with the identity proof at the registrar office or portal.",
			"Pay the search and copy fee.",
			"Collect the certified copy or receive it by post."
		],
		fees: "Search fee plus per-copy fee as notified by the municipal body.",
		processingTime: "Up to 15 working days for a complete application.",
		validity: "Permanent; the certified copy does not expire.",
		source: "Public Records Access & Certified Copies SOP v3.0, Section 2.1",
		lastUpdated: "2025-10-12"
	},
	{
		id: "guide-income-certificate",
		title: "Income Certificate",
		aliases: [
			"income certificate",
			"income proof",
			"salary certificate"
		],
		authority: "Tehsil / Revenue Office",
		requiredDocuments: [
			"Application form with a self-declaration of income",
			"Proof of identity and address",
			"Salary slip, Form 16 or an income affidavit",
			"Ration card or family details as required by the office"
		],
		acceptableProofs: ["Income: latest three salary slips, Form 16, income tax return acknowledgement", "Identity: Aadhaar, voter identity card"],
		steps: [
			"Fill the application at the revenue office or the state service portal.",
			"Attach the income and identity proofs.",
			"Complete the field verification if the office requests it.",
			"Download or collect the signed certificate."
		],
		fees: "Nominal service charge; several state portals issue it free of cost.",
		processingTime: "7 to 15 working days.",
		validity: "Usually one financial year.",
		source: "Public Records Access & Certified Copies SOP v3.0, Annexure A",
		lastUpdated: "2025-10-12"
	}
];
var SEED_CASES = [
	{
		id: "GRV-2026-0431",
		requesterName: "Rohit Salvi",
		contact: "rohit.salvi@example.com",
		channel: "Web form",
		text: "My salary was deducted last month without any notice. An amount of Rs. 4,250 is missing from my March payslip and nobody informed me why. My employee ID is EMP-20418. Please correct this and release the arrears.",
		priority: "High",
		submittedAt: "2026-02-09T09:12:00.000Z"
	},
	{
		id: "GRV-2026-0432",
		requesterName: "Neha Kulkarni",
		contact: "neha.k@example.com",
		channel: "Web form",
		text: "I cancelled order ORD-88F241 on 02/02/2026 and the refund of Rs. 1,899 has still not been credited to my card. It has been more than two weeks now and the app only says refund initiated.",
		priority: "Medium",
		submittedAt: "2026-02-09T11:40:00.000Z"
	},
	{
		id: "GRV-2026-0433",
		requesterName: "Imran Shaikh",
		contact: "9876543210",
		channel: "Web form",
		text: "The employee portal keeps failing when I try to submit my timesheet. It shows ERR-5032 and then logs me out. I have tried a password reset but the login page still crashes.",
		priority: "High",
		submittedAt: "2026-02-08T06:05:00.000Z",
		advance: {
			assignTo: "IT Support",
			status: "In Progress",
			comment: {
				author: "K. Lanke",
				text: "Reproduced on the timesheet module. Raised a priority incident with the platform team.",
				at: "2026-02-08T08:15:00.000Z"
			}
		}
	},
	{
		id: "GRV-2026-0434",
		requesterName: "Anonymous Requester",
		contact: "feedback@example.com",
		channel: "Web form",
		text: "This is completely unacceptable and I am very upset. Nobody ever helps me and I want someone to do something about it immediately.",
		priority: "Medium",
		submittedAt: "2026-02-10T04:22:00.000Z"
	},
	{
		id: "GRV-2026-0435",
		requesterName: "Sunita Rane",
		contact: "sunita.rane@example.com",
		channel: "Web form",
		text: "There is heavy water leakage in the second floor washroom of Block B and the floor is slippery. It has been leaking since Monday and nobody has attended it.",
		priority: "High",
		submittedAt: "2026-02-06T05:30:00.000Z",
		advance: {
			assignTo: "Facilities & Maintenance",
			status: "Resolved",
			approvedResponse: {
				approver: "A. Patil",
				sentAt: "2026-02-06T07:10:00.000Z"
			}
		}
	},
	{
		id: "GRV-2026-0436",
		requesterName: "Deepak Mane",
		contact: "deepak.mane@example.com",
		channel: "Web form",
		text: "My approved leave was cancelled by my manager without discussion and my attendance is now marked absent for those days. I have raised it twice with my reporting manager and nothing changed.",
		priority: "Medium",
		submittedAt: "2026-02-07T10:00:00.000Z",
		advance: {
			assignTo: "Human Resources",
			status: "Escalated"
		}
	}
];
//#endregion
export { SEED_CASES as i, POLICY_CHUNKS as n, POLICY_DOCUMENTS as r, DOCUMENT_GUIDES as t };
