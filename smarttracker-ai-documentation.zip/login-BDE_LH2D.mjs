import { r as __toESM } from "../_runtime.mjs";
import { R as require_react, v as useNavigate, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { O as login, S as getAuthUser } from "./router-DxxzZ2Qy.mjs";
import { a as Field, t as Callout } from "./ui-DYNAo6oe.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-BDE_LH2D.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LoginPage() {
	const navigate = useNavigate();
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const currentUser = getAuthUser();
	const handleLogin = async (e) => {
		e.preventDefault();
		if (!email || !password) {
			setError("Please enter both email and password.");
			return;
		}
		setLoading(true);
		setError(null);
		try {
			await login({
				email,
				password
			});
			const user = getAuthUser();
			if (user?.role === "admin") navigate({ to: "/admin" });
			else if (user?.role === "cleaner") navigate({ to: "/cleaner" });
			else navigate({ to: "/submit" });
		} catch (err) {
			setError(err?.message || "Login failed. Please check credentials.");
		} finally {
			setLoading(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "main",
		className: "wrap page max-w-md",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: "Authentication"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-2xl font-extrabold sm:text-3xl",
				children: "Sign in"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm muted",
				children: "Sign in to access your role workspace using real backend JWT authentication."
			}),
			currentUser ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Callout, {
					tone: "info",
					title: "Already Signed In",
					children: [
						"Currently authenticated as User ID ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: ["#", currentUser.id] }),
						" (Role: ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: currentUser.role }),
						")."
					]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-6 grid gap-4 card card-pad",
				onSubmit: handleLogin,
				children: [
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, {
						tone: "danger",
						title: "Authentication Error",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Email Address",
						htmlFor: "login-email",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "login-email",
							type: "email",
							className: "input",
							required: true,
							value: email,
							onChange: (e) => setEmail(e.target.value),
							placeholder: "user@example.com"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Password",
						htmlFor: "login-password",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "login-password",
							type: "password",
							className: "input",
							required: true,
							value: password,
							onChange: (e) => setPassword(e.target.value),
							placeholder: "••••••••"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "btn btn-primary mt-2 w-full",
						disabled: loading,
						children: loading ? "Signing in..." : "Sign in"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 card card-pad text-xs muted space-y-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-bold text-sm text-(--fg)",
						children: "Demo Accounts"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Admin:" }), " admin@smarttracker.in / admin12345"] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Cleaner:" }), " phase3cleaner@example.com / cleaner123"] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Citizen:" }), " phase3test@example.com / testpass123"] })
				]
			})
		]
	});
}
//#endregion
export { LoginPage as component };
