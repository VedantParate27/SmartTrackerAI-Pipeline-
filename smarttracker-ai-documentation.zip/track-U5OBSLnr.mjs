import { r as __toESM } from "../_runtime.mjs";
import { u as STATUS_MEANING } from "./taxonomy-tJaYsAgr.mjs";
import { R as require_react, _ as Link, v as useNavigate, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as getBackendImageUrl, r as Route$4, w as getComplaint } from "./router-DxxzZ2Qy.mjs";
import { a as Field, c as StatusPill, o as PriorityPill, p as formatDateTime, t as Callout } from "./ui-DYNAo6oe.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/track-U5OBSLnr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TrackPage() {
	const { id = "" } = Route$4.useSearch();
	const navigate = useNavigate({ from: Route$4.fullPath });
	const [query, setQuery] = (0, import_react.useState)(id);
	const [found, setFound] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!id.trim()) {
			setFound(null);
			setError(null);
			setLoading(false);
			return;
		}
		setLoading(true);
		setError(null);
		getComplaint(id.trim()).then((complaint) => {
			setFound(complaint);
		}).catch((err) => {
			setFound(null);
			setError(err?.message || `No grievance found for reference ${id}`);
		}).finally(() => {
			setLoading(false);
		});
	}, [id]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "main",
		className: "wrap page max-w-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: "Case status"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-2xl font-extrabold sm:text-3xl",
				children: "Track a case"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm muted",
				children: [
					"Enter the reference or tracking ID from your acknowledgement, for example",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mono",
						children: "1"
					}),
					" or ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mono",
						children: "TRK-a1b2c3d4"
					}),
					"."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-5 flex flex-col gap-2 sm:flex-row sm:items-end",
				onSubmit: (event) => {
					event.preventDefault();
					navigate({ search: { id: query.trim() } });
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Tracking reference",
						htmlFor: "track-id",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "track-id",
							className: "input",
							value: query,
							placeholder: "1 or TRK-a1b2c3d4",
							autoComplete: "off",
							spellCheck: false,
							onChange: (event) => setQuery(event.target.value)
						})
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "btn btn-primary",
					children: "Check status"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6",
				"aria-live": "polite",
				children: [
					loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "card card-pad text-center muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "m-0",
							children: "Loading complaint status from backend..."
						})
					}) : null,
					!loading && id && error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, {
						tone: "warn",
						title: "No case found",
						children: error
					}) : null,
					!loading && found ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "card card-pad",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-start justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "kicker",
											children: "Reference"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mono mt-0.5 text-lg font-extrabold",
											children: ["ID #", found.id]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: found.status }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriorityPill, { priority: found.priority })]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm muted",
									children: STATUS_MEANING[found.status] ?? `Status: ${found.status}`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
									className: "mt-4 grid grid-cols-1 gap-3 text-sm sm:grid-cols-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "kicker",
											children: "Submitted"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "m-0",
											children: formatDateTime(found.submittedAt)
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "kicker",
											children: "Last updated"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "m-0",
											children: formatDateTime(found.updatedAt)
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "kicker",
											children: "Department"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "m-0",
											children: found.assignedDepartment ?? "Sanitation & Waste Management"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "kicker",
											children: "Location"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "m-0",
											children: found.location?.type === "gps" ? `GPS (${found.location.latitude?.toFixed(4)}, ${found.location.longitude?.toFixed(4)})` : found.location?.type === "manual" ? found.location.manualAddress : "Not specified"
										})] })
									]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "card card-pad",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "card-title text-base font-bold",
									children: "Complaint Details"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-(--fg)",
									children: found.text
								}),
								found.wasteType || found.severity ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 grid grid-cols-2 gap-2 text-xs bg-(--surface-2) p-3 rounded-lg",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "kicker",
										children: "AI Waste Type"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-semibold capitalize m-0",
										children: found.wasteType ?? "Unclassified"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "kicker",
										children: "Severity Level"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-semibold capitalize m-0",
										children: found.severity ?? "Normal"
									})] })]
								}) : null,
								found.aiReasoning ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 text-xs muted",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "kicker",
										children: "AI Analysis Note"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "m-0 italic",
										children: found.aiReasoning
									})]
								}) : null,
								found.imagePath ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "kicker",
										children: "Submitted Image"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-1 max-w-sm rounded overflow-hidden border border-(--line)",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: getBackendImageUrl(found.imagePath) ?? void 0,
											alt: "Complaint waste evidence",
											className: "w-full h-auto max-h-64 object-cover"
										})
									})]
								}) : null
							]
						})]
					}) : null
				]
			}),
			!found && !loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-6 text-sm muted",
				children: [
					"Do not have a reference yet?",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/submit",
						children: "Submit a grievance"
					}),
					"."
				]
			}) : null
		]
	});
}
//#endregion
export { TrackPage as component };
