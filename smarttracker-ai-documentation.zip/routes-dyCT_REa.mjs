import { _ as Link, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as DemoNotice } from "./ui-DYNAo6oe.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-dyCT_REa.js
var import_jsx_runtime = require_jsx_runtime();
var PIPELINE = [
	{
		step: "01",
		title: "Intake",
		body: "You describe the problem in plain language. The case is stored unchanged and given a tracking reference."
	},
	{
		step: "02",
		title: "Classify & route",
		body: "Intent, entities and the responsible department are predicted, with a confidence score and alternatives."
	},
	{
		step: "03",
		title: "Retrieve policy",
		body: "Dense vector search and BM25 keyword search run over active policy versions only."
	},
	{
		step: "04",
		title: "Draft with citations",
		body: "A reply is drafted from the retrieved evidence alone. Without evidence, the system abstains."
	},
	{
		step: "05",
		title: "Human approval",
		body: "An administrator edits, approves or reassigns. Nothing is sent to you without that approval."
	}
];
var ENTRIES = [
	{
		to: "/submit",
		label: "Submit a grievance",
		body: "One form. No department to choose."
	},
	{
		to: "/track",
		label: "Track a case",
		body: "Check status with your reference number."
	},
	{
		to: "/guide",
		label: "Document guide",
		body: "Checklists, steps, fees and timelines."
	}
];
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "main",
		className: "wrap page",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "max-w-3xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: "Grievance routing & resolution pipeline"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 text-3xl font-extrabold tracking-tight sm:text-4xl",
						children: "Describe the problem. We find the right desk and the right policy."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-base leading-relaxed muted sm:text-lg",
						children: "SmartTracker AI reads your complaint, recommends the responsible department and drafts a reply that cites the policy it relied on. Every reply is reviewed and approved by a person before it reaches you."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-col gap-2 sm:flex-row sm:items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/submit",
					className: "btn btn-primary btn-block sm:w-auto",
					children: "Submit a grievance"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/track",
					className: "btn btn-block sm:w-auto",
					children: "Track an existing case"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DemoNotice, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				"aria-labelledby": "entries-heading",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "entries-heading",
					className: "sr-only",
					children: "Where to start"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 sm:grid-cols-3",
					children: ENTRIES.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: entry.to,
						className: "card card-pad no-underline transition-colors hover:border-(--accent)",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm font-extrabold text-(--fg)",
							children: entry.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block text-xs muted",
							children: entry.body
						})]
					}, entry.to))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				"aria-labelledby": "pipeline-heading",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "pipeline-heading",
					className: "text-lg font-extrabold",
					children: "How a case moves"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-4 grid list-none gap-3 p-0 md:grid-cols-5",
					children: PIPELINE.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "card card-pad",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "kicker",
								children: item.step
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-1 text-sm font-extrabold",
								children: item.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs leading-relaxed muted",
								children: item.body
							})
						]
					}, item.step))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				"aria-labelledby": "safeguards-heading",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "safeguards-heading",
					className: "text-lg font-extrabold",
					children: "What the system will not do"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 grid list-none gap-2 p-0 text-sm muted sm:grid-cols-2",
					children: [
						"Send an AI-written response without a named human approver.",
						"State a policy rule that is not backed by a retrieved, active source.",
						"Silently approve a low-confidence classification — those go to manual triage.",
						"Give legal, medical or emergency advice, or make a final disciplinary decision."
					].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "card card-pad flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": "true",
							className: "font-extrabold text-(--danger)",
							children: "✕"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item })]
					}, item))
				})]
			})
		]
	});
}
//#endregion
export { Home as component };
