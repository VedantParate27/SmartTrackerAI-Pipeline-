import { r as __toESM } from "../_runtime.mjs";
import { s as PRIORITIES } from "./taxonomy-tJaYsAgr.mjs";
import { R as require_react, _ as Link, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { j as submitWasteComplaint } from "./router-DxxzZ2Qy.mjs";
import { a as Field, c as StatusPill, d as formatBytes, t as Callout } from "./ui-DYNAo6oe.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/submit-Mh_juzYH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var EMPTY = {
	requesterName: "",
	contact: "",
	priority: "Medium",
	text: "",
	consent: false
};
var MIN_TEXT = 30;
var ALLOWED_IMAGE_TYPES = [
	"image/jpeg",
	"image/png",
	"image/webp"
];
var MAX_IMAGE_BYTES = 10485760;
function validate(values, imageFile) {
	const errors = {};
	if (values.requesterName.trim().length < 2) errors.requesterName = "Enter your name (at least 2 characters).";
	const contact = values.contact.trim();
	const isEmail = /^[\w.+-]+@[\w-]+\.[\w.]{2,}$/.test(contact);
	const isPhone = /^(?:\+91[\s-]?)?[6-9]\d{9}$/.test(contact.replace(/\s/g, ""));
	if (!contact) errors.contact = "Enter an email address or a 10-digit mobile number.";
	else if (!isEmail && !isPhone) errors.contact = "That does not look like a valid email address or mobile number.";
	if (values.text.trim().length < MIN_TEXT) errors.text = `Describe the problem in at least ${MIN_TEXT} characters.`;
	if (!imageFile) errors.image = "An image of the waste issue is required.";
	else if (!ALLOWED_IMAGE_TYPES.includes(imageFile.type)) errors.image = "Unsupported image type. Only JPEG, PNG, and WEBP are accepted.";
	else if (imageFile.size > MAX_IMAGE_BYTES) errors.image = `Image is too large. Maximum allowed size is ${formatBytes(MAX_IMAGE_BYTES)}.`;
	if (!values.consent) errors.consent = "Please confirm you agree to the processing of this complaint.";
	return errors;
}
function SubmitPage() {
	const [values, setValues] = (0, import_react.useState)(EMPTY);
	const [imageFile, setImageFile] = (0, import_react.useState)(null);
	const [errors, setErrors] = (0, import_react.useState)({});
	const [serverError, setServerError] = (0, import_react.useState)(null);
	const [submitting, setSubmitting] = (0, import_react.useState)(false);
	const [submittedComplaint, setSubmittedComplaint] = (0, import_react.useState)(null);
	const [failedAttempts, setFailedAttempts] = (0, import_react.useState)(0);
	const errorSummary = (0, import_react.useRef)(null);
	const [gpsStatus, setGpsStatus] = (0, import_react.useState)("idle");
	const [gpsCoords, setGpsCoords] = (0, import_react.useState)(null);
	const [manualAddress, setManualAddress] = (0, import_react.useState)("");
	function requestGpsLocation() {
		if (!("geolocation" in navigator)) {
			setGpsStatus("unavailable");
			return;
		}
		setGpsStatus("requesting");
		navigator.geolocation.getCurrentPosition((position) => {
			setGpsCoords({
				latitude: position.coords.latitude,
				longitude: position.coords.longitude
			});
			setGpsStatus("granted");
		}, (error) => {
			setGpsCoords(null);
			setGpsStatus(error.code === error.PERMISSION_DENIED ? "denied" : "unavailable");
		}, {
			enableHighAccuracy: true,
			timeout: 1e4,
			maximumAge: 6e4
		});
	}
	function clearGpsLocation() {
		setGpsCoords(null);
		setGpsStatus("idle");
	}
	function currentLocation() {
		if (gpsStatus === "granted" && gpsCoords) return {
			type: "gps",
			latitude: gpsCoords.latitude,
			longitude: gpsCoords.longitude,
			manualAddress: null
		};
		if (manualAddress.trim()) return {
			type: "manual",
			latitude: null,
			longitude: null,
			manualAddress: manualAddress.trim()
		};
		return null;
	}
	(0, import_react.useEffect)(() => {
		if (failedAttempts > 0) errorSummary.current?.focus();
	}, [failedAttempts]);
	function update(key, value) {
		setValues((current) => ({
			...current,
			[key]: value
		}));
		setErrors((current) => ({
			...current,
			[key]: void 0
		}));
	}
	async function onSubmit(event) {
		event.preventDefault();
		setServerError(null);
		const found = validate(values, imageFile);
		setErrors(found);
		if (Object.keys(found).length > 0) {
			setFailedAttempts((count) => count + 1);
			return;
		}
		setSubmitting(true);
		try {
			const formData = new FormData();
			formData.append("complaint_text", values.text.trim());
			if (imageFile) formData.append("image", imageFile);
			const loc = currentLocation();
			if (loc) {
				if (loc.type === "gps" && loc.latitude != null && loc.longitude != null) {
					formData.append("location_type", "gps");
					formData.append("latitude", String(loc.latitude));
					formData.append("longitude", String(loc.longitude));
				} else if (loc.type === "manual" && loc.manualAddress) {
					formData.append("location_type", "manual");
					formData.append("manual_address", loc.manualAddress);
				}
			}
			const complaint = await submitWasteComplaint(formData);
			setSubmittedComplaint(complaint);
		} catch (error) {
			console.error("Failed to submit complaint:", error);
			setServerError(error instanceof Error ? error.message : "Unable to submit the complaint. Please try again.");
		} finally {
			setSubmitting(false);
		}
	}
	if (submittedComplaint) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "main",
		className: "wrap page max-w-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: "Acknowledgement"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-2xl font-extrabold sm:text-3xl",
				children: "Your grievance has been registered"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card card-pad mt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "kicker",
						children: "Tracking reference"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mono mt-1 text-xl font-extrabold tracking-wide sm:text-2xl",
						children: submittedComplaint.id
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: submittedComplaint.status }) })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "hint mt-2",
					children: "Keep this reference. You will need it to check the status of your grievance."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, {
					tone: "info",
					title: "What happens next",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
						className: "m-0 mt-1 list-decimal space-y-1 pl-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Automated AI vision analysis evaluates the complaint image and determines waste severity." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "If verification or human review is required, the report is routed for admin review." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "An administrator assigns a cleaner team or verifies the task upon completion." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "You can track updates in real-time using your tracking reference." })
						]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex flex-col gap-2 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/track",
					search: { id: submittedComplaint.id },
					className: "btn btn-primary btn-block sm:w-auto",
					children: "Track this case"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-block sm:w-auto",
					onClick: () => {
						setValues(EMPTY);
						setImageFile(null);
						setSubmittedComplaint(null);
						setServerError(null);
						setFailedAttempts(0);
						clearGpsLocation();
						setManualAddress("");
					},
					children: "Submit another grievance"
				})]
			})
		]
	});
	const errorList = Object.values(errors).filter(Boolean);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "main",
		className: "wrap page max-w-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: "Step 1 of 1"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-2xl font-extrabold sm:text-3xl",
				children: "Submit a grievance"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-relaxed muted",
				children: "Describe the issue and upload a clear photo. AI vision will automatically detect waste type and severity."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, {
					tone: "info",
					title: "Privacy notice",
					children: "Your complaint text and image are stored so the case can be routed, analyzed, and resolved by cleanup teams."
				})
			}),
			serverError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, {
					tone: "danger",
					title: "Submission failed",
					children: serverError
				})
			}) : null,
			errorList.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				ref: errorSummary,
				tabIndex: -1,
				"aria-live": "assertive",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, {
					tone: "danger",
					title: `${errorList.length} ${errorList.length === 1 ? "field needs" : "fields need"} attention`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "m-0 mt-1 list-disc space-y-0.5 pl-4",
						children: errorList.map((message) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: message }, message))
					})
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-5 grid gap-4",
				onSubmit,
				noValidate: true,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Your name",
						htmlFor: "requesterName",
						required: true,
						error: errors.requesterName,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "requesterName",
							name: "requesterName",
							className: "input",
							autoComplete: "name",
							value: values.requesterName,
							disabled: submitting,
							"aria-invalid": Boolean(errors.requesterName),
							"aria-describedby": errors.requesterName ? "requesterName-error" : void 0,
							onChange: (event) => update("requesterName", event.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Email or mobile number",
						htmlFor: "contact",
						required: true,
						hint: "Used only to acknowledge the case and send the approved response.",
						error: errors.contact,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "contact",
							name: "contact",
							className: "input",
							inputMode: "email",
							autoComplete: "email",
							value: values.contact,
							disabled: submitting,
							"aria-invalid": Boolean(errors.contact),
							"aria-describedby": errors.contact ? "contact-error" : "contact-hint",
							onChange: (event) => update("contact", event.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "What went wrong?",
						htmlFor: "text",
						required: true,
						hint: `${values.text.trim().length} of ${MIN_TEXT} characters minimum. Describe the problem or location context.`,
						error: errors.text,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							id: "text",
							name: "text",
							className: "textarea",
							value: values.text,
							disabled: submitting,
							"aria-invalid": Boolean(errors.text),
							"aria-describedby": errors.text ? "text-error" : "text-hint",
							placeholder: "Example: Uncollected garbage pile blocking pedestrian path near main street market.",
							onChange: (event) => update("text", event.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Waste Image",
						htmlFor: "image",
						required: true,
						hint: `Upload a photo of the waste (JPEG, PNG, or WEBP, max ${formatBytes(MAX_IMAGE_BYTES)}).`,
						error: errors.image,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "image",
							name: "image",
							type: "file",
							className: "file-input",
							accept: "image/jpeg,image/png,image/webp",
							disabled: submitting,
							"aria-invalid": Boolean(errors.image),
							"aria-describedby": errors.image ? "image-error" : "image-hint",
							onChange: (event) => {
								const file = event.target.files?.[0] ?? null;
								setImageFile(file);
								setErrors((curr) => ({
									...curr,
									image: void 0
								}));
							}
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Location",
						htmlFor: "manualAddress",
						hint: "Optional, but helps route the cleanup crew. Share your current location or type an address.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "btn",
										onClick: requestGpsLocation,
										disabled: gpsStatus === "requesting" || submitting,
										children: gpsStatus === "requesting" ? "Getting your location…" : gpsStatus === "granted" ? "Location shared" : "Share my current location"
									}), gpsStatus === "granted" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "btn btn-quiet",
										onClick: clearGpsLocation,
										disabled: submitting,
										children: "Clear"
									}) : null]
								}),
								gpsStatus === "granted" && gpsCoords ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "hint",
									children: [
										"Using your current location (",
										gpsCoords.latitude.toFixed(5),
										",",
										" ",
										gpsCoords.longitude.toFixed(5),
										")."
									]
								}) : null,
								gpsStatus === "denied" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, {
									tone: "warn",
									title: "Location permission denied",
									children: "You can still type an address below instead."
								}) : null,
								gpsStatus === "unavailable" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, {
									tone: "warn",
									title: "Location unavailable",
									children: "Your browser or device could not provide a location. Type an address below instead."
								}) : null,
								gpsStatus !== "granted" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "manualAddress",
									name: "manualAddress",
									className: "input",
									placeholder: "e.g. Near 5th Cross Road, Indiranagar",
									value: manualAddress,
									disabled: submitting,
									onChange: (event) => setManualAddress(event.target.value)
								}) : null
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "How urgent is it?",
						htmlFor: "priority",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							id: "priority",
							name: "priority",
							className: "select",
							value: values.priority,
							disabled: submitting,
							onChange: (event) => update("priority", event.target.value),
							children: PRIORITIES.map((priority) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: priority,
								children: priority
							}, priority))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "check-row",
						htmlFor: "consent",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "consent",
							name: "consent",
							type: "checkbox",
							checked: values.consent,
							disabled: submitting,
							"aria-invalid": Boolean(errors.consent),
							onChange: (event) => update("consent", event.target.checked)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["I confirm the details above are correct and I agree to this complaint being stored and processed to resolve it.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "req",
							"aria-hidden": "true",
							children: "*"
						})] })]
					}), errors.consent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "field-error",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": "true",
							children: "!"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: errors.consent })]
					}) : null] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "btn btn-primary btn-block sm:w-auto",
							disabled: submitting,
							children: submitting ? "Submitting grievance..." : "Submit grievance"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "btn btn-quiet btn-block sm:w-auto",
							children: "Cancel"
						})]
					})
				]
			})
		]
	});
}
//#endregion
export { SubmitPage as component };
