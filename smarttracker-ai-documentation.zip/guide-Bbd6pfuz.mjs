import { r as __toESM } from "../_runtime.mjs";
import { t as DOCUMENT_GUIDES } from "./seed-CgRMZeL5.mjs";
import { R as require_react, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Field, f as formatDate, t as Callout } from "./ui-DYNAo6oe.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/guide-Bbd6pfuz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** FR-29: identify a supported document or service from a plain-language query. */
function matchGuides(query) {
	const cleaned = query.trim().toLowerCase();
	if (cleaned.length < 2) return [];
	return DOCUMENT_GUIDES.map((guide) => {
		const aliasHit = guide.aliases.some((alias) => cleaned.includes(alias) || alias.includes(cleaned));
		const titleHits = guide.title.toLowerCase().split(/[^a-z]+/).filter((word) => word.length > 3 && cleaned.includes(word)).length;
		return {
			guide,
			score: (aliasHit ? 2 : 0) + titleHits
		};
	}).filter((item) => item.score > 0).sort((a, b) => b.score - a.score).map((item) => item.guide);
}
function GuideDetail({ guide }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "card card-pad",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "kicker",
						children: guide.authority
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 text-xl font-extrabold",
						children: guide.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-4 grid grid-cols-1 gap-3 text-sm sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "kicker",
								children: "Fees"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "m-0",
								children: guide.fees
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "kicker",
								children: "Processing time"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "m-0",
								children: guide.processingTime
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "kicker",
								children: "Validity"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "m-0",
								children: guide.validity
							})] })
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "card-head",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "card-title",
						children: "Documents you need"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "m-0 list-none divide-rows p-0",
					children: guide.requiredDocuments.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-2 px-4 py-2.5 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": "true",
							className: "font-extrabold text-(--accent)",
							children: "✓"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item })]
					}, item))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "card-head",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "card-title",
						children: "Accepted proofs"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "m-0 list-disc space-y-1.5 py-3 pl-8 pr-4 text-sm muted",
					children: guide.acceptableProofs.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: item }, item))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "card-head",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "card-title",
						children: "Steps to apply"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "m-0 list-decimal space-y-1.5 py-3 pl-8 pr-4 text-sm",
					children: guide.steps.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: item }, item))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Callout, {
				tone: "info",
				title: "Source",
				children: [
					guide.source,
					" · last updated ",
					formatDate(guide.lastUpdated),
					". Only the fields recorded in this source are shown; anything not listed here has not been filled in. Confirm fees and timelines with the issuing authority before you apply."
				]
			})
		]
	});
}
function GuidePage() {
	const [query, setQuery] = (0, import_react.useState)("");
	const [selectedId, setSelectedId] = (0, import_react.useState)(null);
	const [searched, setSearched] = (0, import_react.useState)(false);
	const matches = (0, import_react.useMemo)(() => matchGuides(query), [query]);
	const selected = selectedId ? DOCUMENT_GUIDES.find((guide) => guide.id === selectedId) ?? null : matches.length === 1 ? matches[0] : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "main",
		className: "wrap page max-w-3xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: "Document requirements guide"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-2xl font-extrabold sm:text-3xl",
				children: "What do I need to apply?"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm muted",
				children: "Ask in plain language — for example “what documents for a new passport”. You do not need to create a complaint to use this."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-5 flex flex-col gap-2 sm:flex-row sm:items-end",
				onSubmit: (event) => {
					event.preventDefault();
					setSelectedId(null);
					setSearched(true);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Your question",
						htmlFor: "guide-query",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "guide-query",
							className: "input",
							value: query,
							placeholder: "documents needed for driving licence",
							onChange: (event) => {
								setQuery(event.target.value);
								setSelectedId(null);
								setSearched(false);
							}
						})
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "btn btn-primary",
					children: "Find checklist"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6",
				"aria-live": "polite",
				children: [
					!selected && matches.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, {
							tone: "warn",
							title: "More than one service matches",
							children: "Pick the one you meant. Nothing is guessed for you."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-2 sm:grid-cols-2",
							children: matches.map((guide) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "card card-pad text-left",
								onClick: () => setSelectedId(guide.id),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm font-extrabold",
									children: guide.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-0.5 block text-xs muted",
									children: guide.authority
								})]
							}, guide.id))
						})]
					}) : null,
					searched && query.trim().length >= 2 && matches.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Callout, {
							tone: "warn",
							title: "Not a supported service yet",
							children: [
								"No checklist is recorded for “",
								query.trim(),
								"”, so no steps can be shown. The services covered in this release are listed below."
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SupportedList, { onPick: setSelectedId })]
					}) : null,
					selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GuideDetail, { guide: selected }) : null,
					!selected && !searched && matches.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SupportedList, { onPick: setSelectedId }) : null
				]
			})
		]
	});
}
function SupportedList({ onPick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		"aria-labelledby": "supported-heading",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			id: "supported-heading",
			className: "kicker",
			children: "Supported services"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 grid gap-2 sm:grid-cols-2",
			children: DOCUMENT_GUIDES.map((guide) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "card card-pad text-left transition-colors hover:border-(--accent)",
				onClick: () => onPick(guide.id),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-sm font-extrabold",
					children: guide.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-0.5 block text-xs muted",
					children: guide.authority
				})]
			}, guide.id))
		})]
	});
}
//#endregion
export { GuidePage as component };
