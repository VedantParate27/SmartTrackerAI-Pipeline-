import { d as STATUS_TONE } from "./taxonomy-tJaYsAgr.mjs";
import { y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ui-DYNAo6oe.js
var import_jsx_runtime = require_jsx_runtime();
/**
* SRS 7.3: timestamps are stored in UTC. They are formatted explicitly here
* rather than with toLocaleString so the server and client render identically.
*/
var MONTHS = [
	"Jan",
	"Feb",
	"Mar",
	"Apr",
	"May",
	"Jun",
	"Jul",
	"Aug",
	"Sep",
	"Oct",
	"Nov",
	"Dec"
];
function pad(value) {
	return String(value).padStart(2, "0");
}
function formatDate(iso) {
	const date = new Date(iso);
	if (Number.isNaN(date.getTime())) return "-";
	return `${pad(date.getUTCDate())} ${MONTHS[date.getUTCMonth()]} ${date.getUTCFullYear()}`;
}
function formatDateTime(iso) {
	const date = new Date(iso);
	if (Number.isNaN(date.getTime())) return "-";
	return `${formatDate(iso)}, ${pad(date.getUTCHours())}:${pad(date.getUTCMinutes())} UTC`;
}
/** Case age, used by the dashboard age filter (FR-17). */
function ageInHours(iso, now) {
	const from = new Date(iso).getTime();
	const to = new Date(now).getTime();
	if (Number.isNaN(from) || Number.isNaN(to)) return 0;
	return Math.max(0, (to - from) / 36e5);
}
function formatAge(iso, now) {
	const hours = ageInHours(iso, now);
	if (hours < 1) return `${Math.round(hours * 60)} min`;
	if (hours < 48) return `${Math.round(hours)} h`;
	return `${Math.round(hours / 24)} d`;
}
function formatBytes(bytes) {
	if (bytes < 1024) return `${bytes} B`;
	if (bytes < 1048576) return `${Math.round(bytes / 1024)} KB`;
	return `${(bytes / 1048576).toFixed(1)} MB`;
}
function percent(value) {
	return `${Math.round(value * 100)}%`;
}
function StatusPill({ status }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "pill",
		"data-tone": STATUS_TONE[status],
		children: status
	});
}
var PRIORITY_TONE = {
	Low: "neutral",
	Medium: "info",
	High: "warn"
};
function PriorityPill({ priority }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "pill",
		"data-tone": PRIORITY_TONE[priority],
		children: [priority, " priority"]
	});
}
/**
* UI-04: confidence is communicated with a number and a word, so the meaning
* never depends on colour alone.
*/
function ConfidenceMeter({ value, threshold, label = "Classifier confidence" }) {
	const low = value < threshold;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-1 flex items-baseline justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "kicker",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-sm font-extrabold",
				children: [
					percent(value),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: low ? "text-(--warn)" : "text-(--ok)",
						children: low ? "· below threshold" : "· above threshold"
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "meter",
			role: "meter",
			"aria-valuenow": Math.round(value * 100),
			"aria-valuemin": 0,
			"aria-valuemax": 100,
			"aria-label": `${label}: ${percent(value)}, threshold ${percent(threshold)}`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "meter-fill",
				"data-tone": low ? "warn" : "ok",
				style: { width: `${Math.max(3, Math.round(value * 100))}%` }
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "hint",
			children: [
				"Configured threshold: ",
				percent(threshold),
				". Cases below it go to manual triage."
			]
		})
	] });
}
var CALLOUT_ICON = {
	neutral: "i",
	info: "i",
	warn: "!",
	danger: "!",
	ok: "✓"
};
function Callout({ tone = "info", title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "callout",
		"data-tone": tone,
		role: tone === "danger" ? "alert" : void 0,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "callout-icon",
			"aria-hidden": "true",
			children: CALLOUT_ICON[tone]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
				className: "block",
				children: title
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: title ? "mt-0.5" : void 0,
				children
			})]
		})]
	});
}
function Field({ label, htmlFor, required, hint, error, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "field",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "label",
				htmlFor,
				children: [label, required ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "req",
					"aria-hidden": "true",
					children: "*"
				}) : null]
			}),
			children,
			hint && !error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "hint",
				id: `${htmlFor}-hint`,
				children: hint
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "field-error",
				id: `${htmlFor}-error`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					"aria-hidden": "true",
					children: "!"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: error })]
			}) : null
		]
	});
}
function SectionCard({ title, meta, children, bodyClassName = "card-pad" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "card-head",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "card-title",
				children: title
			}), meta ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs muted",
				children: meta
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: bodyClassName,
			children
		})]
	});
}
function EmptyState({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "px-1 py-8 text-center text-sm muted",
		children
	});
}
function DemoNotice() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, {
		tone: "info",
		title: "Demo build — frontend only",
		children: "No FastAPI backend, model provider or vector store is connected. The classification, hybrid retrieval and draft generation shown here are simulated locally from the seeded policy set so the SRS workflow can be reviewed end to end."
	});
}
//#endregion
export { Field as a, StatusPill as c, formatBytes as d, formatDate as f, EmptyState as i, ageInHours as l, percent as m, ConfidenceMeter as n, PriorityPill as o, formatDateTime as p, DemoNotice as r, SectionCard as s, Callout as t, formatAge as u };
