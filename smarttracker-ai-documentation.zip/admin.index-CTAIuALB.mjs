import { r as __toESM } from "../_runtime.mjs";
import { i as DEPARTMENTS, l as STATUSES, r as CONFIG, s as PRIORITIES } from "./taxonomy-tJaYsAgr.mjs";
import { R as require_react, _ as Link, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as isVisible, x as getAdminQueue, y as useAppState } from "./router-DxxzZ2Qy.mjs";
import { c as StatusPill, i as EmptyState, l as ageInHours, m as percent, t as Callout, u as formatAge } from "./ui-DYNAo6oe.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.index-CTAIuALB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var AGE_OPTIONS = [
	{
		value: "any",
		label: "Any age"
	},
	{
		value: "24",
		label: "Older than 24 h"
	},
	{
		value: "72",
		label: "Older than 72 h"
	}
];
var CONFIDENCE_OPTIONS = [
	{
		value: "any",
		label: "Any confidence"
	},
	{
		value: "low",
		label: "Below threshold"
	},
	{
		value: "high",
		label: "Above threshold"
	}
];
var OPEN_STATUSES = /* @__PURE__ */ new Set(["Pending Review", "Manual Triage"]);
function summary(item) {
	const text = item.text.trim();
	return text.length > 120 ? `${text.slice(0, 120)}…` : text;
}
function QueuePage() {
	const { session, now } = useAppState();
	const [backendCases, setBackendCases] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		getAdminQueue().then((items) => {
			const mapped = items.map((item) => ({
				id: String(item.id),
				requesterName: `User ${item.user_id}`,
				contact: "",
				channel: "Web",
				language: "English",
				text: item.complaint_text,
				attachments: [],
				priority: "Medium",
				status: item.status === "awaiting_review" ? "Pending Review" : "Submitted",
				submittedAt: item.created_at,
				updatedAt: item.updated_at,
				assignedDepartment: item.department,
				location: item.location_type != null ? {
					type: item.location_type,
					latitude: item.latitude,
					longitude: item.longitude,
					manualAddress: item.manual_address
				} : null,
				classification: item.category ? {
					intent: item.category,
					department: item.department ?? "other",
					confidence: item.confidence_score ?? 0,
					alternatives: [],
					modelVersion: "Gemini",
					taxonomyVersion: "Phase 2",
					ruleApplied: null,
					overriddenBy: null
				} : null,
				entities: [],
				evidence: [],
				aiDraft: null,
				editedDraft: null,
				resolution: null,
				closureReason: null,
				duplicateOf: null,
				comments: [],
				audit: []
			}));
			setBackendCases(mapped);
		}).catch((error) => {
			console.error("Failed to load admin queue:", error);
		});
	}, []);
	const [search, setSearch] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("any");
	const [department, setDepartment] = (0, import_react.useState)("any");
	const [priority, setPriority] = (0, import_react.useState)("any");
	const [age, setAge] = (0, import_react.useState)("any");
	const [confidence, setConfidence] = (0, import_react.useState)("any");
	const permitted = (0, import_react.useMemo)(() => backendCases.filter((item) => isVisible(item, session)), [backendCases, session]);
	const stats = (0, import_react.useMemo)(() => [
		{
			label: "Awaiting review",
			value: permitted.filter((item) => OPEN_STATUSES.has(item.status)).length
		},
		{
			label: "Manual triage",
			value: permitted.filter((item) => item.status === "Manual Triage").length
		},
		{
			label: "Escalated",
			value: permitted.filter((item) => item.status === "Escalated").length
		},
		{
			label: "With department",
			value: permitted.filter((item) => item.status === "Assigned to Department" || item.status === "In Progress").length
		},
		{
			label: "Resolved or closed",
			value: permitted.filter((item) => item.status === "Resolved" || item.status === "Closed").length
		}
	], [permitted]);
	const filtered = (0, import_react.useMemo)(() => {
		const needle = search.trim().toLowerCase();
		return permitted.filter((item) => {
			if (needle) {
				if (!`${item.id} ${item.requesterName} ${item.text} ${item.classification?.intent ?? ""}`.toLowerCase().includes(needle)) return false;
			}
			if (status !== "any" && item.status !== status) return false;
			if (priority !== "any" && item.priority !== priority) return false;
			if (department !== "any") {
				if ((item.assignedDepartment ?? item.classification?.department) !== department) return false;
			}
			if (age !== "any" && ageInHours(item.submittedAt, now) < Number(age)) return false;
			if (confidence !== "any") {
				const score = item.classification?.confidence;
				if (score === void 0) return confidence === "low";
				const low = score < CONFIG.confidenceThreshold;
				if (confidence === "low" ? !low : low) return false;
			}
			return true;
		}).sort((a, b) => new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime());
	}, [
		permitted,
		search,
		status,
		department,
		priority,
		age,
		confidence,
		now
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			session.departments !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Callout, {
				tone: "info",
				title: "Department-limited view",
				children: [
					"You are signed in as ",
					session.role,
					" for",
					" ",
					session.departments.join(", "),
					". Cases routed elsewhere are not listed."
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				"aria-label": "Queue summary",
				className: "grid grid-cols-2 gap-2 sm:grid-cols-5",
				children: stats.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "stat",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "stat-value m-0",
						children: stat.value
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "m-0 mt-0.5 text-xs muted",
						children: stat.label
					})]
				}, stat.label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card card-pad",
				"aria-labelledby": "filters-heading",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "filters-heading",
					className: "kicker",
					children: "Filters"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 grid gap-2 sm:grid-cols-2 lg:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "sm:col-span-2 lg:col-span-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "sr-only",
								htmlFor: "q",
								children: "Search cases"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "q",
								className: "input",
								type: "search",
								placeholder: "Search reference, requester or text",
								value: search,
								onChange: (event) => setSearch(event.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "sr-only",
							htmlFor: "f-status",
							children: "Status"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							id: "f-status",
							className: "select",
							value: status,
							onChange: (event) => setStatus(event.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "any",
								children: "Any status"
							}), STATUSES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item,
								children: item
							}, item))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "sr-only",
							htmlFor: "f-dept",
							children: "Department"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							id: "f-dept",
							className: "select",
							value: department,
							onChange: (event) => setDepartment(event.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "any",
								children: "Any department"
							}), DEPARTMENTS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item,
								children: item
							}, item))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "sr-only",
							htmlFor: "f-priority",
							children: "Priority"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							id: "f-priority",
							className: "select",
							value: priority,
							onChange: (event) => setPriority(event.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "any",
								children: "Any priority"
							}), PRIORITIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: item,
								children: [item, " priority"]
							}, item))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "sr-only",
							htmlFor: "f-age",
							children: "Age"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							id: "f-age",
							className: "select",
							value: age,
							onChange: (event) => setAge(event.target.value),
							children: AGE_OPTIONS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item.value,
								children: item.label
							}, item.value))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "sr-only",
							htmlFor: "f-confidence",
							children: "Confidence"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							id: "f-confidence",
							className: "select",
							value: confidence,
							onChange: (event) => setConfidence(event.target.value),
							children: CONFIDENCE_OPTIONS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item.value,
								children: item.label
							}, item.value))
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card overflow-hidden",
				"aria-labelledby": "queue-heading",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "card-head",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "queue-heading",
							className: "card-title",
							children: "Case queue"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs muted",
							children: [
								filtered.length,
								" of ",
								permitted.length,
								" cases"
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "queue-head kicker",
						"aria-hidden": "true",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Reference" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Complaint" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Department" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Confidence" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Age" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "divide-rows",
						children: filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, { children: "No cases match the current filters." }) : filtered.map((item) => {
							const owner = item.assignedDepartment ?? item.classification?.department ?? "—";
							const score = item.classification?.confidence;
							const low = score !== void 0 && score < CONFIG.confidenceThreshold;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/admin/cases/$caseId",
								params: { caseId: item.id },
								className: "queue-row",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mono font-bold",
											children: item.id
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: item.status })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "m-0 text-sm",
											children: summary(item)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "m-0 mt-0.5 text-xs subtle",
											children: [
												item.classification?.intent ?? "Not yet classified",
												" ·",
												" ",
												item.requesterName,
												" · ",
												item.priority,
												" priority"
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs muted",
										"data-label": "Department",
										children: owner
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs",
										"data-label": "Confidence",
										children: score === void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "subtle",
											children: "Pending"
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: low ? "font-bold text-(--warn)" : "",
											children: [percent(score), low ? " · low" : ""]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs muted",
										"data-label": "Age",
										children: formatAge(item.submittedAt, now)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-right text-sm text-(--accent)",
										"aria-hidden": "true",
										children: "Open →"
									})
								]
							}, item.id);
						})
					})
				]
			})
		]
	});
}
//#endregion
export { QueuePage as component };
