import { r as __toESM } from "../_runtime.mjs";
import { i as DEPARTMENTS, p as can } from "./taxonomy-tJaYsAgr.mjs";
import { R as require_react, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as ingestPolicy, h as retirePolicy, i as activatePolicy, y as useAppState } from "./router-DxxzZ2Qy.mjs";
import { a as Field, f as formatDate, s as SectionCard, t as Callout } from "./ui-DYNAo6oe.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.knowledge-BXSYy9Cu.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var POLICY_TYPES = [
	"Policy",
	"SOP",
	"Circular"
];
var ACCEPTED_TYPES = ["application/pdf", "text/plain"];
var STATUS_TONE = {
	Active: "ok",
	"Pending Approval": "warn",
	Retired: "neutral"
};
var EMPTY = {
	title: "",
	owner: "",
	department: DEPARTMENTS[0],
	policyType: "Policy",
	jurisdiction: "Organisation-wide",
	version: "",
	effectiveDate: "",
	pages: "1",
	supersedes: ""
};
function KnowledgePage() {
	const { policies, session } = useAppState();
	const [form, setForm] = (0, import_react.useState)(EMPTY);
	const [fileName, setFileName] = (0, import_react.useState)("");
	const [errors, setErrors] = (0, import_react.useState)([]);
	const [report, setReport] = (0, import_react.useState)(null);
	if (!can(session, "policy.manage")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, {
		tone: "danger",
		title: "Not authorised",
		children: "Policy ingestion and version control are limited to the knowledge manager role. Switch the signed-in user above to continue."
	});
	function update(key, value) {
		setForm((current) => ({
			...current,
			[key]: value
		}));
	}
	function onSubmit(event) {
		event.preventDefault();
		const found = [];
		if (form.title.trim().length < 4) found.push("Enter the document title.");
		if (form.owner.trim().length < 2) found.push("Enter the document owner.");
		if (!/^\d+(\.\d+)?$/.test(form.version.trim())) found.push("Enter a version number such as 1.0 or 2.4.");
		if (!/^\d{4}-\d{2}-\d{2}$/.test(form.effectiveDate)) found.push("Choose the effective date.");
		const pages = Number(form.pages);
		if (!Number.isInteger(pages) || pages < 1 || pages > 500) found.push("Page count must be a whole number between 1 and 500.");
		if (!fileName) found.push("Attach the policy file (PDF or TXT).");
		setErrors(found);
		if (found.length > 0) return;
		setReport(ingestPolicy({
			title: form.title.trim(),
			owner: form.owner.trim(),
			department: form.department,
			policyType: form.policyType,
			jurisdiction: form.jurisdiction.trim() || "Organisation-wide",
			version: form.version.trim(),
			effectiveDate: form.effectiveDate,
			pages,
			fileName,
			supersedes: form.supersedes || null
		}));
		setForm(EMPTY);
		setFileName("");
	}
	const activeCount = policies.filter((policy) => policy.status === "Active").length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Callout, {
				tone: "info",
				title: "Only active versions are authoritative",
				children: [
					activeCount,
					" of ",
					policies.length,
					" documents are active. Retired versions stay readable for audit but are never retrieved for a new draft (FR-27, FR-28, BR-04)."
				]
			}),
			report ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SectionCard, {
				title: "Ingestion report",
				meta: `${report.id} · ${report.title} v${report.version}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "grid grid-cols-2 gap-3 text-sm sm:grid-cols-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "kicker",
								children: "Chunks generated"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "m-0 font-bold",
								children: report.ingestion.chunks
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "kicker",
								children: "Pages"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "m-0 font-bold",
								children: report.pages
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "kicker",
								children: "Unreadable pages"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "m-0 font-bold",
								children: report.ingestion.unreadablePages.length === 0 ? "None" : report.ingestion.unreadablePages.join(", ")
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "kicker",
								children: "Status"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "m-0 font-bold",
								children: report.status
							})] })
						]
					}),
					report.ingestion.warnings.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, {
							tone: "warn",
							title: "Warnings",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "m-0 mt-1 list-disc space-y-0.5 pl-4",
								children: report.ingestion.warnings.map((warning) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: warning }, warning))
							})
						})
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-col gap-2 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-primary btn-sm",
							onClick: () => {
								activatePolicy(report.id);
								setReport(null);
							},
							children: "Approve and activate this version"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-quiet btn-sm",
							onClick: () => setReport(null),
							children: "Leave pending"
						})]
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SectionCard, {
				title: "Upload a policy document",
				meta: "FR-24, FR-25",
				children: [errors.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, {
						tone: "danger",
						title: "Fix these fields",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "m-0 mt-1 list-disc space-y-0.5 pl-4",
							children: errors.map((message) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: message }, message))
						})
					})
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "grid gap-4 sm:grid-cols-2",
					onSubmit,
					noValidate: true,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "sm:col-span-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Title",
								htmlFor: "p-title",
								required: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "p-title",
									className: "input",
									value: form.title,
									onChange: (event) => update("title", event.target.value)
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Owner",
							htmlFor: "p-owner",
							required: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "p-owner",
								className: "input",
								value: form.owner,
								onChange: (event) => update("owner", event.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Department",
							htmlFor: "p-dept",
							required: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								id: "p-dept",
								className: "select",
								value: form.department,
								onChange: (event) => update("department", event.target.value),
								children: DEPARTMENTS.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: option,
									children: option
								}, option))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Document type",
							htmlFor: "p-type",
							required: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								id: "p-type",
								className: "select",
								value: form.policyType,
								onChange: (event) => update("policyType", event.target.value),
								children: POLICY_TYPES.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: option,
									children: option
								}, option))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Jurisdiction",
							htmlFor: "p-jurisdiction",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "p-jurisdiction",
								className: "input",
								value: form.jurisdiction,
								onChange: (event) => update("jurisdiction", event.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Version",
							htmlFor: "p-version",
							required: true,
							hint: "For example 1.0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "p-version",
								className: "input",
								inputMode: "decimal",
								value: form.version,
								onChange: (event) => update("version", event.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Effective date",
							htmlFor: "p-date",
							required: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "p-date",
								type: "date",
								className: "input",
								value: form.effectiveDate,
								onChange: (event) => update("effectiveDate", event.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Pages",
							htmlFor: "p-pages",
							required: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "p-pages",
								type: "number",
								min: 1,
								max: 500,
								className: "input",
								value: form.pages,
								onChange: (event) => update("pages", event.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Supersedes",
							htmlFor: "p-supersedes",
							hint: "Activating this version will retire the one it replaces.",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								id: "p-supersedes",
								className: "select",
								value: form.supersedes,
								onChange: (event) => update("supersedes", event.target.value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "Nothing — this is a new document"
								}), policies.filter((policy) => policy.status === "Active").map((policy) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: policy.id,
									children: [
										policy.title,
										" v",
										policy.version
									]
								}, policy.id))]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "sm:col-span-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Policy file",
								htmlFor: "p-file",
								required: true,
								hint: "PDF or TXT. The file is not uploaded anywhere in this demo; only its name is kept.",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "p-file",
									type: "file",
									className: "file-input",
									accept: ACCEPTED_TYPES.join(","),
									onChange: (event) => {
										const file = event.target.files?.[0];
										if (!file) {
											setFileName("");
											return;
										}
										if (!ACCEPTED_TYPES.includes(file.type)) {
											setErrors(["Only PDF or TXT policy documents can be ingested."]);
											setFileName("");
											return;
										}
										setErrors([]);
										setFileName(file.name);
									}
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "sm:col-span-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								className: "btn btn-primary btn-block sm:w-auto",
								children: "Extract and ingest"
							})
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
				title: "Policy versions",
				meta: `${policies.length} documents`,
				bodyClassName: "",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "table-scroll",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "table",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								scope: "col",
								children: "Document"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								scope: "col",
								children: "Department"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								scope: "col",
								children: "Version"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								scope: "col",
								children: "Effective"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								scope: "col",
								children: "Status"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								scope: "col",
								children: "Retrievable"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								scope: "col",
								children: "Action"
							})
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: policies.map((policy) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold",
									children: policy.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mono block subtle",
									children: policy.id
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block text-xs subtle",
									children: [
										policy.policyType,
										" · owner ",
										policy.owner,
										" ·",
										" ",
										policy.ingestion.chunks,
										" chunks"
									]
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "text-xs",
								children: policy.department
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "whitespace-nowrap",
								children: ["v", policy.version]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "whitespace-nowrap text-xs",
								children: formatDate(policy.effectiveDate)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "pill",
								"data-tone": STATUS_TONE[policy.status],
								children: policy.status
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "text-xs",
								children: policy.status === "Active" ? "Yes" : "No — audit only"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: policy.status === "Pending Approval" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-sm",
								onClick: () => activatePolicy(policy.id),
								children: "Activate"
							}) : policy.status === "Active" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-sm",
								onClick: () => retirePolicy(policy.id),
								children: "Retire"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs subtle",
								children: "—"
							}) })
						] }, policy.id)) })]
					})
				})
			})
		]
	});
}
//#endregion
export { KnowledgePage as component };
